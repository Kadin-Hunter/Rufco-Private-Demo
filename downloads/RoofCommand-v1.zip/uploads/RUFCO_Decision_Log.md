# RUFCO Decision Log

## 2026-08-20 — Hard cap confirmed: no work past 20 hrs/$600/wk without Ivan's approval; no overage rate set
**Decision:** Ivan told Kadin directly not to exceed 20 hours or $600/week without getting his approval first. He did not name a rate for hours beyond that.
**Why:** Ivan's explicit instruction, relayed 2026-08-20.
**Scope impact:** Resolves the open question from the 8/17 proposal and 8/19 counter-offer about whether the original $75/hr overage rate and $4,000/month cap still applied. They don't, by default — the operative rule now is a hard stop at 20 hrs/$600/wk unless Ivan approves more in writing/text first. If overage work is ever needed, the rate must be asked for at that time, not assumed.

## 2026-08-20 — Workstation ordered and paid — Phase 0 item complete
**Decision:** Ivan ordered the MSI workstation for ~$2,500 (pass-through cost, confirmed paid by Ivan).
**Why:** Follows from the 8/19 discussion where Ivan said he'd order it that night.
**Scope impact:** none — closes out one Phase 0 task. Workstation setup/join-to-tenant work still pending once it arrives.

## 2026-08-20 — New scope item: digitize the job intake/work order form
**Decision:** Digitize RufCo's paper job intake/work order form. First step: a fillable PDF version of the existing blank form (Kadin has the blank form). Longer-term: build it as a conditional question/answer flow inside RoofCommand so only the fields relevant to the selected job type or area (e.g. gutters, shingles) are asked, instead of showing every line on every job. Ingest the captured data into the CRM.
**Why:** Ivan's request, relayed 2026-08-20. Fits directly under the "PDF/document intake to eliminate his desk paperwork" and "per-job-type step logic" requirements already sharpened for Phase 4 on 8/19 — this is a concrete implementation of scope already agreed, not new scope outside the charter.
**Scope impact:** none against the charter. Adds a concrete near-term deliverable (fillable PDF) ahead of the full conditional-logic CRM version. The reference JPEG of the work order form already in the vault (`8-17-26-scope-meeting/reference-materials/rufco-job-work-order-form.jpeg`) may be an earlier/different version — confirm against the blank PDF Kadin has before building.

## 2026-08-19 — CRM working name: "RoofCommand"
**Decision:** Ivan chose "RoofCommand" as the working name for the CRM being built in Phase 4.
**Why:** Ivan's preference, given on 8/19.
**Scope impact:** none — naming only. Not final branding, subject to change before launch.

## 2026-08-17 — 6/26 plan and pricing superseded
**Decision:** The prior plan (two ChatGPT prompts for $750, $2,500 automation upsell) is obsolete.
**Why:** Doesn't match what Ivan actually asked for on the 8/17 scope call — a built-once, owned CRM plus a weekly retainer, not per-deliverable pricing.
**Scope impact:** Full replacement with the 8-phase roadmap below.

## 2026-08-17 — Pricing model: open weekly retainer (Model C)
**Decision:** Chose an open weekly retainer with no fixed per-week deliverable commitment, over Model A (fixed price per phase) and Model B (weekly retainer against an agreed task list).
**Why:** Matches Ivan's own stated ask ("how much do you need a week"), absorbs both parties' interruptions (his travel, Kadin's job search/interviews), removes per-deliverable negotiation, converts cleanly into a sustainment retainer later.
**Alternatives considered:** Model A rejected — recreates the failed $5,000 quote conversation from June and makes every change a negotiation. Model B is the fallback if Ivan later wants more weekly visibility than Model C's Friday update gives him.
**Scope impact:** none — pricing structure decision only.

## 2026-08-17 — Rate proposed at $600/week for 10 hours
**Decision:** Original client-facing proposal set $600/week covering 10 hours ($60/hr), $75/hr for hours 11+, $4,000/month hard cap without written approval, two weeks' notice either side.
**Why:** Below every published market band (independent IT consultant $80/hr+, Texas MSP $150-175/hr) as a deliberate first-client/reference discount. Matches Ivan's existing spending anchors (~$2,167/mo). Superseded the internal roadmap draft's looser $500/wk-at-10-15hr range, which worked out to as low as $33/hr.
**Status:** Superseded by Ivan's counter-offer below.

## 2026-08-17 — RingCentral selected for phone system (Phase 2)
**Decision:** Port Ivan's existing number from Verizon to RingCentral. Not competitively shopped.
**Why:** Kadin has already built this exact configuration for a prior client. Ivan's only condition — keep the same number — is satisfied by a port.
**Scope impact:** none.

## 2026-08-17 — Sequencing: M365 before CRM, Insurance phase after CRM despite higher ROI
**Decision:** Phase 1 (M365/identity) runs before Phase 4 (CRM), and Phase 5 (insurance/claims — the highest-ROI phase) is sequenced after Phase 4 rather than pulled forward.
**Why:** The CRM needs to be built on Microsoft's identity/permissions model, not bolted on after. Claims tracking depends on job/document records existing in the CRM first.
**Scope impact:** none — sequencing only.

## 2026-08-1X — Ivan's counter-offer: $600/week for 20 hours — ACCEPTED
**Decision:** Kadin accepted Ivan's counter via text: $30/hr, guaranteed 20 hours/week, same $600/week total as the original $60/hr-at-10-hours proposal. First 90 days at this rate, then a sit-down review of results. If the system is producing value, Ivan is open to revisiting the rate upward at that point.
**Why (Ivan's stated reasoning, from his text):** Not comfortable committing to $60/hr before the system is proven. Wants the same $600/week to buy double the hours instead, on the logic that more hours gets the CRM and automation built faster. Framed the trade explicitly as steady work plus reference plus referrals in exchange for the lower rate during the unproven period, not an attempt to undervalue the work.
**Flag (context, not a live decision anymore):** $30/hr is below the $40/hr floor set in the original rate analysis. Accepted anyway, time-boxed to 90 days with an explicit review point rather than an open-ended commitment — that structure is what makes it workable.
**Milestone:** 90-day rate review. Approximate date depends on actual kickoff date, calculate as kickoff + 90 days once Phase 0 starts and add to the Roadmap.
**Open:** Whether the $75/hr overage rate and $4,000/month cap from the original proposal still apply unchanged at 20 hours/week — not addressed in Ivan's text, still needs confirming.
**Status:** Final for the first 90 days. Not yet reconciled against the Phase 4 build-option framework below (Options 1/2/3 were priced against a 10-hour baseline and need rework at 20 hours).

## SUPERSEDED — Phase 4 build option (priced at 10 hrs/wk baseline)
Original framing: Option 1 (15 hrs/wk during CRM build, $900/wk, same $10,800 total, ~6 weeks faster), Option 2 (stay at $600/wk/10hrs, same total, 18 weeks), Option 3 (core-only build, ~$7,200).
**Status:** This entire framework assumed a 10-hour weekly baseline. With the baseline now at 20 hours/week per the counter-offer, CRM timeline and these three options need to be recalculated — 20 hrs/wk likely finishes Phase 4 faster than any of the original options without an hours bump. Rework before treating any of these numbers as current.

# RoofCommand: Build Roadmap

**Date:** 2026-08-20
**Aligns to:** `PHASE-4-SCOPE-AND-TIMELINE-DRAFT.md` stages A through F
**Status:** Planning estimate, not a delivery promise. No build starts before Ivan approves the Phase 4 scope draft and the two flagged scope changes.

---

## Ground rules

- 20 productive hours per week, hard cap. No work past 20 hrs or $600 in a week without Ivan's approval, no overage rate set.
- Every increment ships behind a feature flag and is demoed to Ivan in the weekly 30-minute review.
- No client data touches the system before Stage B is accepted and the backup/restore path is verified.
- Roofr and CompanyCam stay live and paid until the 30-day parallel pilot passes. Cancellation is Ivan's decision, after the pilot, in writing.
- Anything Ivan asks for mid-build that is not in this plan goes to the Phase 5+ backlog in writing, with a timeline impact number attached. That is the top risk on this engagement.

---

## Timeline at a glance

| Stage | Weeks | Theme | Gate |
|---|---:|---|---|
| A | 1-2 | Discovery, decisions, scaffold | Scope, roles, statuses, pilot job confirmed. Repo runs locally. |
| B | 3-6 | Core CRM and pipeline | Ivan can run the pipeline on test data. Exception dashboard live. |
| C | 7-10 | Work execution and intake | Andrew completes a test work order end to end on his phone. |
| D | 11-14 | Photos, money, time clock | 50-photo field test passes including airplane-mode capture. |
| E | 15-17 | Email history, hardening, migration | Real historical data imported. Backup restore verified. |
| F | 18-21 | Parallel pilot | One real job runs 30 days in both systems with no recordkeeping failure. |

**Planning window: 17 build weeks plus a 4-week pilot.** This is one week longer than the current Phase 4 draft's 16 weeks, and that week is the added scope from photo capture and estimates if both are approved. If Ivan approves only one, subtract a week. If he approves neither, the original 16-week window stands and photos stay as CompanyCam links.

---

## Stage A: Discovery and foundation (weeks 1-2)

**Decisions to close before code**

- [ ] Phase 4 scope draft approved, including or excluding the two flagged scope changes
- [ ] Job statuses confirmed with Ivan, including the exact name of the status between signed and production
- [ ] Job types and areas enumerated (shingle, metal, TPO, gutters, repair, other)
- [ ] Roles confirmed and the permission matrix in `SPEC-Feature-Design.md` signed off
- [ ] Pilot job named, and the four users who will touch it
- [ ] Hosting decision: GoDaddy VPS (~$20/mo) vs office server (~$700 one time, $0/mo). **This also decides the language** (Node vs PHP), so it blocks every ticket below. Existing shared hosting was analyzed and rejected as a destination: the 250,000-inode cap is hit around month 20 of photos. See `DECISION-Stack-and-Architecture.md`.
- [ ] GoDaddy credentials received, actual hosting plan confirmed (may be Managed WordPress or Website Builder, neither of which can host a custom app)
- [ ] Shared Drive owner account for the photo mirror and backups
- [ ] Artifacts collected: blank intake/work-order form, one finished claim file with emails, one sample estimate, one sample final invoice

**Build**

| Ticket | Description |
|---|---|
| A-01 | Monorepo scaffold: npm workspaces, `shared`/`api`/`web`, TypeScript strict, ESLint, Prettier |
| A-02 | `docker-compose.yml` for local dev: postgres, minio, api, web |
| A-03 | Drizzle schema for the full core data model from the architecture doc, migration 0001 |
| A-04 | Seed script with realistic fake roofing data (30 customers, 45 jobs across all statuses) |
| A-05 | Fastify server skeleton, health endpoint, Zod error handling, request logging |
| A-06 | Vite React PWA shell, Tailwind, router, bottom tab bar, dark/light mode with system default |
| A-07 | Google OAuth login, domain restriction, sessions table, revocation on user disable |
| A-08 | Permission middleware driven by `packages/shared/permissions.ts`, with unit tests per role |
| A-09 | CI: GitHub Actions running typecheck, lint, unit tests on every PR |
| A-10 | `docs/RUNBOOK.md` first pass: how to run, deploy, back up, restore |

**Gate:** repo runs locally with one command, four seeded roles log in and see different things, CI green.

---

## Stage B: Core CRM and pipeline (weeks 3-6)

| Ticket | Description |
|---|---|
| B-01 | Customer CRUD, search by name, address, phone, email (Postgres full-text + trigram) |
| B-02 | Property records linked to customers, repeat jobs at one address linked |
| B-03 | Job CRUD with the four-field creation rule, auto job numbering |
| B-04 | Job status machine with configurable transition requirements, `status_entered_at` maintained |
| B-05 | `job_status_history` and append-only `activity` table with database triggers preventing update/delete |
| B-06 | Structured job attributes (material, profile, color, manufacturer, squares, pitch, layers) and search over them |
| B-07 | Pipeline board: kanban on desktop, one-column swipe on mobile, drag to change status, days-in-status and overdue indicators |
| B-08 | Pipeline list view with filters, sorts, and saved filters |
| B-09 | Next action as a first-class field: owner, due date, and enforcement that its absence is reportable |
| B-10 | **Exception dashboard** (Ivan's home screen): no-next-action, overdue, stuck-past-threshold, aged dollars, sync failures |
| B-11 | Per-status stall thresholds editable by Ivan in settings |
| B-12 | Notes with append-only history, voice dictation via the native keyboard |
| B-13 | Role-shaped home screen routing for all four roles |
| B-14 | Full export: every table to CSV plus a manifest, one click, owner only |
| B-15 | Nightly `pg_dump` + MinIO sync to Shared Drive, encrypted, with `ops/restore-verify.sh` |

**Gate:** Ivan runs the pipeline on seeded data for a week, a deliberately stalled test job appears correctly on the exception dashboard, and a restore from backup is demonstrated.

---

## Stage C: Work execution and intake (weeks 7-10)

| Ticket | Description |
|---|---|
| C-01 | Checklist templates by job type and area, editable by Ivan, versioned |
| C-02 | Work order CRUD, assignment, scheduled date and window, access notes |
| C-03 | Andrew's home screen: today's work orders, clock button, camera, nothing else |
| C-04 | Work order execution screen: navigate link, one-tap call, scope, materials, checklist |
| C-05 | Checklist items with photo-required, note-required, number-required variants |
| C-06 | Checklist completion gating configured status transitions |
| C-07 | Tasks and assignments with one owner and one due date, reassignment logged |
| C-08 | Reminder rule engine on pg-boss: trigger types, audience, cadence, digest batching |
| C-09 | Text-style email notifications, subject line carrying the fact, plain body |
| C-10 | Fillable PDF of RufCo's blank intake/work-order form (print path preserved) |
| C-11 | Conditional intake question tree: JSON-defined, one question per screen, editable by Ivan |
| C-12 | Intake answers writing into structured job fields plus a stored answer set |
| C-13 | Offline foundation: Dexie queue, service worker, persistent storage request, visible sync chip with queue count |
| C-14 | Offline caching of this week's jobs, work orders, checklists, and contacts |

**Gate:** Andrew opens the PWA on his iPhone, completes a full test work order including a photo-required checklist item, in airplane mode for part of it, and everything lands correctly after reconnecting.

---

## Stage D: Photos, money, and time clock (weeks 11-14)

> D-01 through D-07 depend on scope-change approval for photo capture. D-08 through D-14 depend on scope-change approval for estimates and invoicing. If either is declined, the corresponding tickets drop and the stage shortens.

| Ticket | Description |
|---|---|
| D-01 | Camera capture from job, work order, and checklist item, with burst capture and tag-once |
| D-02 | Capture-time metadata: GPS, device clock, user, job, written at shutter, immutable by trigger |
| D-03 | `location_unverified` flagging and badge when GPS is unavailable at capture, never backfilled |
| D-04 | Upload pipeline: original stored immutable, sharp-generated 300px and 1200px derivatives, presigned URL delivery |
| D-05 | Job photo timeline: grouped by day, filter by tag, user, elevation; virtualized grid with scroll restoration |
| D-06 | Nightly Drive mirror job with per-job folders and metadata CSV, plus count reconciliation surfaced on the exception dashboard |
| D-07 | CompanyCam bulk import preserving original capture timestamps |
| D-08 | Price book with categories, cost, price, versioning |
| D-09 | Assemblies expanding to line items driven by measurements |
| D-10 | Measurement fields with source and confidence, unverified-satellite marking |
| D-11 | Estimate builder with revisions, diff between revisions, margin view restricted to Ivan |
| D-12 | Estimate PDF output, branded, with job photos on the cover |
| D-13 | Invoice generated from accepted estimate, manual payment records, aging |
| D-14 | Job and company money rollups: contract, deposit, payments, supplements, depreciation outstanding, balance |
| D-15 | Time clock: per-job clock in/out, capture-time location, required close-out note |
| D-16 | Geofence, **only if** the written employee notice and Andrew's opt-in are recorded first |
| D-17 | Weekly timesheet view per person, exportable |

**Gate:** the 50-photo two-job field test passes, including a batch shot in airplane mode, all with correct capture metadata and all present in the Drive mirror the next morning. A standard reroof estimate builds in under two minutes.

---

## Stage E: Communication history, migration, hardening (weeks 15-17)

| Ticket | Description |
|---|---|
| E-01 | Gmail API read integration, per-job threading by customer address plus a job reference token |
| E-02 | Email timeline on the job with sender, date, subject, snippet, attachment count, deep link to the Gmail thread |
| E-03 | One-tap pull of an email attachment into job documents |
| E-04 | Manual call logging (who, when, outcome, next action) |
| E-05 | Unified activity timeline with type filters |
| E-06 | Document intake: upload, categorize, full-text search over extracted text where available |
| E-07 | Data migration from Roofr export: customers, jobs, statuses mapped, with a reconciliation report |
| E-08 | Performance pass: list virtualization, query indexes, photo grid on a real 300-photo job |
| E-09 | Accessibility and glove-usability pass: touch targets, contrast, thumb-zone audit |
| E-10 | Security review: permission tests per role per endpoint, presigned URL expiry, session revocation |
| E-11 | Monthly restore verification run and logged for the first time on real data |
| E-12 | Role-specific training material: one page per role, plus a short screen recording each |

**Gate:** real historical data is in, a restore has been verified on it, and each of the four users has been trained on their screen only.

---

## Stage F: Parallel pilot (weeks 18-21)

Not a build stage. One agreed real job runs in RoofCommand and Roofr simultaneously for 30 days.

**Weekly during the pilot**
- Reconcile the two systems on the pilot job, log every discrepancy
- Collect one piece of friction per user per week, in their words
- Fix defects only. New features go to the backlog, no exceptions.

**Pilot passes when** (mirrors the approved Phase 4 acceptance criteria)
- The pilot job has a complete customer, job, work order, checklist, task, document, financial, and activity record
- Each assigned user performed their role on the mobile web interface
- Ivan viewed the record, changed a reminder rule himself, and exported and restored the agreed data set
- 30 days with no material recordkeeping failure
- Only then does the Roofr cancellation conversation happen, and only with Ivan's explicit approval

---

## Phase 5+ backlog (recorded, not built)

Everything here came out of the research or the spec and is deliberately deferred. Recording it is how scope creep gets contained.

**Claims and money (Phase 5, highest financial ROI)**
- Claim entity with its own status track and aging clock
- Supplements as estimate revisions with reason codes and approval tracking
- Depreciation release tracking with an aging alert
- Adjuster contact log
- Permit tracking with inspection dates
- Action-ranked claims dashboard with total outstanding dollars on one screen
- Read-only Xactimate import at most, never write

**Photos and presentation**
- On-image annotation
- Branded photo report PDFs with selectable detail
- Voice-to-checklist creation
- Before/after comparison
- Public website gallery and portfolio
- Video capture

**Communication**
- SMS logging and send via RingCentral (depends on Phase 2)
- Customer portal with job status
- Automated status update emails (Phase 6, approval-gated)
- E-signature on estimates

**Money**
- Online card and ACH payment collection
- Accounting sync (note: bookkeeping is out of charter scope)
- Material ordering integrations (ABC Supply, Beacon)

**AI (Phase 6, approval-gated, nothing sends without a human click)**
- Morning digest to Ivan
- Voice intake drafting job records
- Email drafting in job context
- Supplement justification drafting
- Schedule and route deduplication (pending the Bumblebee feasibility answer)

**Platform**
- Capacitor wrapper if true offline-first proves necessary after the pilot
- Crew and subcontractor scoped access (Phase 7)
- Public REST API documentation for third-party integration

---

## Risks

| Risk | Severity | Mitigation |
|---|---|---|
| Scope creep. Ivan named a dozen features on one call. | Highest | Feature list frozen at Stage A. Every new idea gets a written backlog entry and a timeline number. No silent additions. |
| Roofr or CompanyCam cancelled before the pilot passes | High | Written rule: no cancellation until 30 days parallel with no material failure, and only on Ivan's explicit approval. |
| Solo maintainer, 20 hrs/week, job search first | High | Four-container stack chosen specifically for this. Every stage ships something usable so a pause is not a total loss. |
| iOS PWA storage eviction breaks offline expectations | Medium | Offline-tolerant is what gets promised, not offline-first. Aggressive upload, visible queue, Capacitor as the documented escape hatch. |
| Ivan unreachable during the Africa/Dubai trip | Medium | Stage A decisions collected before Sunday 08/23 or the stage slips. Do not build on assumed answers. |
| Photo storage growth outrunning the VPS disk | Low | ~72 GB/year estimate, Drive mirror as long-tail archive, reviewed quarterly. |
| Bus factor: one person knows the system | Medium | `docs/RUNBOOK.md` maintained as a deliverable, not an afterthought. Ivan holds all credentials and owns every account. |

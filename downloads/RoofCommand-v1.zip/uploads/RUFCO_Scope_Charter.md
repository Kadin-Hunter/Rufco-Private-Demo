# RUFCO Scope Charter

## What RUFCO is
Hunter Ops consulting engagement for RufCo Construction LLC (Ivan Mata, roofing/construction, Amarillo TX). An 8-phase build (Phase 0-7 plus ongoing sustainment) moving RufCo off Roofr and paper onto an owned Google Workspace-based CRM + claims-tracking + AI-assistant stack. Ivan is staying on Google Workspace/Gmail (long-time user, decided 2026-08-19), not migrating to M365. Weekly retainer, not a per-deliverable contract.

**CRM working name:** "RoofCommand" (chosen by Ivan, 2026-08-19; not final branding).

## In scope
- Phase 0: workstation, domain/DNS/hosting recovery, backups
- Phase 1: Google Workspace role-based access/account structure, security baseline (MFA/2SV, SPF/DKIM/DMARC)
- Phase 2: Verizon number ported to RingCentral, auto attendant, call groups, business SMS
- Phase 3: website fixes, lead capture, follow-up automation, SEO basics
- Phase 4: CRM core (customers, jobs, work orders, checklists, reminders, permissions, time clock, invoice/payment tracking) — the main deliverable
- Phase 5: insurance/claim pipeline, aging alerts, supplement tracking, permit tracking
- Phase 6: AI assistant layer (morning digest, voice intake, email drafting, supplement drafting) — approval-gated, no autonomous sends
- Phase 7 (optional): mobile/field access, digital forms
- Ongoing sustainment: monitoring, backups, patching, support, quarterly review
- Pass-through costs billed direct to Ivan at cost, no markup (hardware, Google Workspace licenses, VoIP, hosting, Roofr/CompanyCam/Xactimate while retained, Google Ads)

## Explicitly out of scope
- Xactimate customization or automation inside it (read-only integration at most, never touch its data)
- Bookkeeping, payroll, tax
- Anything touching subcontractor classification or employment structure
- Physical network/cabling beyond the one workstation
- Covert monitoring of employees — location sharing requires disclosure and consent or it doesn't happen

## Stakeholders
- Ivan Mata — Owner, RufCo. Client, final decision-maker, global admin on all systems.
- Joel (Floyd) — Salesman/manager, runs Andrew, owns his own customers. Elevated access, explicitly NOT full visibility.
- Javier ("Javi") — Salesman, manages crews/inspections. Elevated access, possible billing visibility.
- Andrew — Runaround/errands/paperwork. Checklist-driven user only, needs work orders + time clock, not a dashboard.
- Roofing crew — 1099 subs, out of system scope until Phase 7.
- Kadin (Hunter Ops) — builder/consultant, W-2 job search remains the priority alongside this engagement.

## Success looks like
Ivan owns (not rents) a working CRM + claims pipeline + AI layer that replaces Roofr and paper, catches stalled/forgotten claims before they age out, and Andrew's team actually uses it. Kadin sustains this without it displacing the job search.

## Pricing (accepted — first 90 days)
$600/week covers 20 hours guaranteed ($30/hr effective), paid Fridays. Accepted by Kadin via text in response to Ivan's counter-offer. Two weeks' notice either side, no penalty. Ivan owns all deliverables, code, data, accounts. Pass-through costs never marked up.

**90-day review.** This rate holds for the first 90 days from kickoff, then Kadin and Ivan sit down to review what's been accomplished. If the system is producing results and value, Ivan has said he's open to revisiting the rate upward. Calculate the actual review date once kickoff starts and track it on the Roadmap.

**Overage resolved (2026-08-20):** Ivan told Kadin directly not to exceed 20 hours or $600/week without his approval first. No overage rate was named. This replaces the original proposal's $75/hr past-included-hours rate and $4,000/month cap — those no longer apply by default. If overage work is ever needed, ask Ivan for a rate at that time rather than assuming one.

**Context:** $30/hr sits below the $40/hr floor identified in the original rate analysis. Accepted as a deliberate trade: guaranteed hours, steady work, a time-boxed 90-day window, and an explicit path to revisit the number rather than an open-ended commitment at that rate.

## Last reviewed
2026-08-17

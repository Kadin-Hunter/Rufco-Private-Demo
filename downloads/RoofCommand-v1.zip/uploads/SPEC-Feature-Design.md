# RoofCommand: Feature Design Spec

**Date:** 2026-08-20
**Companion docs:** `RESEARCH-Competitive-Teardown.md`, `DECISION-Stack-and-Architecture.md`, `ROADMAP-Build-Plan.md`
**Status:** Draft for Ivan's approval. Sections marked SCOPE CHANGE require written sign-off before build.

---

## Design principles (apply to every screen)

1. **One job, one next action, one owner.** A job with no next action is a defect the system reports, not a state the system allows.
2. **Two taps to the common thing.** Clock in, add a photo, mark a checklist item, log a note. If it takes more than two taps from the home screen for the role that does it, the design is wrong.
3. **Required fields are the enemy.** Creating a job requires four fields. Everything else is demanded by a status transition, not by a form.
4. **The field never types what the phone already knows.** Time, location, user, and job context are captured, not entered.
5. **Nothing is silently lost.** Sync state, upload queues, and email delivery are visible. Failures are loud.
6. **Every screen is the mobile screen.** Desktop is the same components at a wider breakpoint.
7. **History is append-only.** Notes and status changes are never destructively edited. Corrections are new entries.

---

## 1. Visual job pipeline

**The problem it solves:** jobs stall between statuses and nobody notices until the customer calls. RufCo has 5 to 7 stalled jobs and one claim that ran six to seven months.

### Object model

One pipeline. Status lives on the **Job** only. A **Customer** has no status. A **Property** (address) is its own record so repeat work on the same roof links together. This directly answers the JobNimbus complaint about Contacts and Jobs carrying duplicate status machines.

### Default job statuses (RufCo-configurable)

```
Lead → Inspection Scheduled → Inspected → Estimate Sent → Signed →
Ready for Production → Scheduled → In Production → Punch List →
Complete → Invoiced → Paid → Closed
```

`Ready for Production` is the status Ivan specifically asked for between signed and production. It is where material ordering, permit, and crew assignment gate.

Claim status is a **separate parallel track** on the same job (Phase 5), not mixed into this list. A job can be `In Production` while its claim is `Supplement Submitted`. Mixing them is what makes incumbent pipelines unreadable on storm work.

### Views

| View | Who | What it does |
|---|---|---|
| **Board** | Ivan, Joel, Javi | Kanban columns by status. Cards show customer, address short form, dollar value, days in status, owner avatar, and a red dot if the next action is overdue. Drag to change status. On mobile the board is horizontally swipeable, one column at a time, full width. |
| **List** | Ivan, office | Dense sortable table. Filter by status, owner, job type, material, date range, dollars outstanding. This is where "find the standing seam job in dark bronze" gets answered. |
| **Map** | Javi, Joel | Jobs plotted by property. Answers "what else is near today's inspection." |
| **Exception dashboard** | Ivan | The first screen built. Not a pipeline view, a defect list. See below. |

### The exception dashboard (Ivan's home screen)

Ranked list, most urgent first, each row one tap to the job:

- Jobs with no next action assigned
- Next actions overdue by owner
- Jobs stuck in one status past a per-status threshold (configurable, defaults: Estimate Sent 5 days, Signed 10 days, Ready for Production 7 days, Invoiced 21 days)
- Dollars outstanding, aged (invoiced but unpaid, depreciation not released)
- Photos captured today with missing or suspect capture metadata
- Failed syncs and upload queue backlog by user

This is the buy-in mechanism. Adoption research is consistent: if the owner does not open it daily, nobody else will.

### Status transition rules

Each status can require: a checklist complete, a document present, a field populated, or a role. Ivan edits these himself in a settings screen, no code change. Example: cannot move to `Ready for Production` until a signed contract document is attached and the material list is filled.

### Aging clock

Every job row stores `status_entered_at`. Days-in-status is displayed everywhere a job appears. This one field is what turns a pipeline into a stall detector.

---

## 2. Mobile-first design

**Target:** iPhone Safari, installed to home screen as a PWA. Confirmed direction, no native iOS app in Phase 4.

### Role-shaped home screens

The single biggest adoption lever. Nobody sees a screen built for somebody else's job.

| Role | Home screen |
|---|---|
| **Andrew** (runaround, checklist user) | Today's work orders as large cards. One clock-in/clock-out button. Camera button. Nothing else. No dashboard, no pipeline, no dollars. |
| **Javier** (crews, inspections) | Today's schedule, map of nearby jobs, camera, work orders for his crews, checklist progress. |
| **Joel** (sales/manager) | His pipeline board only, his customers, his next actions, his estimates. Explicitly not full visibility. |
| **Ivan** (owner) | Exception dashboard, then full pipeline, then everything. |

### Interaction rules

- Thumb zone: primary actions in the bottom third. Bottom tab bar, not a hamburger.
- Minimum 44px touch targets, tested with gloves in mind.
- No horizontal scrolling except the deliberate board swipe.
- Forms are one question per screen where the flow is conditional (see intake below), not a wall of fields.
- Every list is virtualized with scroll position restored on back navigation. This is an explicit acceptance test, because the AccuLynx photo-scroll-reset complaint is the kind of small daily irritation that kills usage.
- Dark and light mode, following the system setting with a manual override. Already in Phase 4 scope.

### Offline behavior

Offline-tolerant, not offline-first. Honest boundaries documented in the architecture doc.

- **Cached for offline read:** today's and this week's jobs, their work orders, checklists, contact numbers, and addresses.
- **Queued while offline:** photo captures, checklist completions, notes, clock in/out events.
- **Not available offline:** pipeline board, search, financials, email history, document viewing.
- **Visible sync state:** a persistent chip showing `Synced` or `3 items queued`. Tapping it lists what is queued. Nothing syncs silently.
- **Conflict rule:** field-captured events are append-only, so there is nothing to merge. Last-write-wins applies only to editable fields, and the losing value is preserved in the activity log.

### Conditional job intake

Ivan's requirement: the intake form should ask only what the selected job type and area need, instead of every line on every job.

Implementation: intake is a JSON-defined question tree, one question per screen, branching on job type (shingle, metal, TPO, gutters, repair) and area. Ivan edits the tree in a settings screen. Answers write into structured job fields plus a stored answer set. The existing paper form's fillable PDF stays as the print path, because Ivan wants paper preserved for older customers.

---

## 3. Photo documentation (CompanyCam parity)

> **SCOPE CHANGE FLAG.** Phase 4 currently authorizes "CompanyCam photo/report pull-in **or** a documented attachment/link workflow." In-app capture, annotation, and generated photo reports exceed that. Recommended split below. Requires Ivan's written approval before build.

### Phase 4 recommended subset (the part that removes the CompanyCam bill)

**Capture**
- Camera opens from any job, work order, or checklist item, and from the home screen with a job picker.
- Burst capture: shoot many, tag once. Field crews will not tag photo by photo.
- Every photo is written with capture-time metadata at shutter: latitude/longitude, device timestamp, user ID, job ID, work-order ID, and checklist item if applicable.
- **The metadata integrity rule.** Capture-time GPS and clock are stored as immutable fields separate from `uploaded_at`. If GPS was unavailable at shutter, the photo is flagged `location_unverified` and shows a badge. It is never backfilled from the upload location. This is the specific failure in most "offline" photo apps and it is the difference between a photo that supports a claim and a photo that does not.
- Offline capture writes the full record plus the image blob to local storage and queues upload.

**Organization**
- Auto-filed to the job. No manual foldering, which is the entire reason CompanyCam is loved.
- Tags: photo type (damage, pre-existing, overview, elevation, close-up, progress, completion, hazard), elevation (front/back/left/right/roof), and free tags. Type is one tap from a preset row.
- Job photo timeline: chronological, grouped by day, filterable by tag and by user.
- Search photos by tag, date, user, and job attributes.

**Durability (answers the "photos vanished" complaint)**
- Primary storage in owned object storage.
- Nightly mirror to a RufCo Google Shared Drive, foldered `Jobs / {Job Number} {Address} / Photos / {YYYY-MM-DD}`, with metadata written to a sidecar CSV per job. Ivan can open a job's photos in Drive with no app involved.
- Photo count per job displayed and reconciled against storage nightly. Mismatch appears on the exception dashboard.
- Original file is never modified. Thumbnails and annotations are derived artifacts.

**Migration**
- Bulk import of existing CompanyCam photos via export, preserving original capture timestamps where the export provides them, so history is not lost when the subscription ends. Do not cancel CompanyCam until import is verified, same rule as Roofr.

### Deferred to Phase 5+ backlog

- On-image annotation (arrows, circles, text callouts)
- Branded photo report PDF generation with selectable detail level
- Voice-to-checklist creation
- Photo comparison (before/after side by side)
- Public website gallery and portfolio site
- Video capture

Rationale: the first group removes a recurring bill and creates the claim evidence trail. The second group is presentation polish, which matters commercially but does not reduce chaos.

---

## 4. Quick estimates and invoicing

> **SCOPE CHANGE FLAG.** Phase 4 currently authorizes financial *visibility* (contract total, deposit, supplements, balance owed, depreciation outstanding) but not estimate generation or invoice issuing. Recommended split below. Requires Ivan's written approval before build.

### Phase 4 recommended subset

**Price book**
- Line items with unit, unit cost, unit price, and category (material, labor, disposal, permit, accessory).
- Assemblies: a named bundle that expands to line items with quantities driven by measurements. Example: "Architectural shingle tear-off and replace" expands per square.
- Ivan owns and edits the price book. Version-stamped, so an old estimate always renders at the prices it was built with.

**Measurements as inputs, not outputs**
- Squares, pitch, ridge, hip, valley, eave, rake, penetrations, layers, stories, waste percentage.
- Each measurement carries `source` (satellite report, hand measured, adjuster scope) and a confidence flag. Estimates built on unverified satellite numbers are visibly marked, because pitch errors are a documented and expensive failure mode.
- Measurement report files (EagleView, Roofr, whatever the source) attach to the job. RoofCommand does not generate measurements. That is a deliberate non-goal.

**Estimate**
- Build from assemblies plus manual lines, in under two minutes for a standard reroof.
- Margin view for Ivan: cost, price, gross margin per line and in total. Joel and Javi see price only unless Ivan grants otherwise.
- Versioning: revision 1, 2, 3, all retained, with a diff showing what changed. Supplements in Phase 5 are literally estimate revisions with an insurance reason code, which is why this structure matters now.
- Output: clean branded PDF. Good typography, real job photos on the cover, scope in plain language.

**Invoice and money tracking**
- Invoice generated from the accepted estimate, no retyping.
- Per job: contract total, deposit received, payments received, supplements approved, depreciation outstanding, balance owed. Job-level and company-level rollups.
- Payment records are manual entries in Phase 4 (check number, ACH reference, date, amount). No payment processing.
- Aging: invoices past 21 days and released-but-uncollected depreciation both appear on the exception dashboard.

### Deferred to Phase 5+ backlog

- E-signature on estimates (Roofr already does this; keep using it during parallel run)
- Online card/ACH payment collection and processing fees
- Automated payment reminder emails (Phase 6 approval-gated)
- QuickBooks or accounting sync (bookkeeping is explicitly out of charter scope)
- Material ordering integrations with ABC Supply or Beacon

---

## 5. Team coordination

**Fully within Phase 4 scope.** No flags.

### Work orders

- Created from a job, typed by job type and area, carrying a required checklist template.
- Assigned to a person with a scheduled date and a window.
- Contains: address with a one-tap navigation link, customer name and phone with one-tap call, scope summary, materials list, access notes (gate code, dog, park where), and the checklist.
- Andrew's version shows exactly this and nothing else.

### Checklists

- Templates per job type and area, editable by Ivan without code.
- Items can require a photo, a note, a number, or just a check. A photo-required item opens the camera in place.
- Checklist completion can gate a job status transition.
- Progress visible on the job card and on the pipeline board.

### Tasks and next actions

- Every task has one owner, one due date, one job. No unassigned tasks. No shared queues in Phase 4.
- The job-level `next_action` is a first-class field, not a note. Its absence is an exception.
- Reassignment is logged with who and when.

### Reminders and notifications

Ivan's requirement was notifications that look like a text rather than a formal email.

- Delivery: email formatted as a short plain-text message, from a RufCo address, subject line carrying the essential fact so it reads correctly in a notification banner. Example subject: `Work order today 8am, 4412 Bowie, tear-off`.
- SMS is deferred until Phase 2 RingCentral business SMS exists. Backlog, not Phase 4.
- Reminder rules are Ivan-configurable: trigger (status age, due date, unassigned next action, checklist stalled), audience (owner, assignee, Ivan), and cadence. No hardcoded rules.
- Digest option so a person gets one message with three items rather than three messages. The adoption research is explicit that unnecessary reminders cause pushback.

### Time clock

- Per-job clock in and out from the work order. One button on Andrew's home screen.
- Required close-out note on clock out. Short, one line, this is the daily field record.
- Location captured at clock in and clock out, using capture-time coordinates with the same integrity rule as photos.
- **Geofence is gated on disclosure and consent.** Charter is explicit: covert monitoring does not happen. Implement only after a written notice and Andrew's opt-in, both stored as records in the system.
- Timesheet view per person per week, exportable. Not payroll, just the record.

### Permissions

Role-based, checked server side on every request, never in the UI only.

| Capability | Ivan | Joel | Javier | Andrew |
|---|---|---|---|---|
| See all jobs | Yes | Own customers only | Assigned crews/inspections | Assigned work orders only |
| See margin/cost | Yes | No | No | No |
| See invoices/payments | Yes | Own jobs, price only | Configurable | No |
| Edit price book | Yes | No | No | No |
| Edit checklists/statuses | Yes | No | No | No |
| Manage users | Yes | No | No | No |
| Export data | Yes | No | No | No |

Access removal must be immediate: disabling a user kills their sessions on the next request.

---

## 6. Customer communication history

**Email history is in Phase 4 scope. SMS and call logging are not.**

### Email

The JobNimbus lesson is the design constraint: a CRM that owns email delivery and silently fails it caused a real BBB complaint. RoofCommand does not become the mail server.

- Gmail stays the system of record for delivery. RoofCommand reads and threads.
- Association: messages link to a job by matching the customer's email addresses, plus a per-job reference token that can be added to a subject line for exact threading.
- Job view shows a chronological thread list: sender, recipients, date, subject, snippet, attachment count, with a link that opens the actual message in Gmail.
- Attachments on a linked message can be pulled into the job's documents in one tap.
- **No sending from RoofCommand in Phase 4.** Drafting and sending is Phase 6, and Phase 6 is approval-gated by charter: nothing sends without a human click.
- Every linked message stores its Gmail message ID and thread ID, so the link is auditable and nothing is "in the CRM" that is not also in Gmail.

### Everything else on the timeline

The job activity log is the unified history and it is append-only:

- Status changes with who and when
- Notes (typed or voice-dictated to text)
- Calls logged manually in Phase 4 (who, when, outcome, next action), automatically once RingCentral exists
- Photos added
- Documents added
- Checklist completions
- Clock events
- Email threads linked
- Estimate and invoice events

Filterable by type. This is the "who did what, when, and why" record already required by Phase 4, and it is what makes a six-month-old claim reconstructable.

### Customer-facing

Out of Phase 4 scope. Customer portal, automated status updates, and review requests are Phase 5+ backlog. Note that the Google Review Engine project already covers the review-request path separately.

---

## Acceptance criteria summary (per feature area)

| Area | Passes when |
|---|---|
| Pipeline | One real job moves through every status, every transition logged, exception dashboard correctly flags a deliberately stalled test job. |
| Mobile | Andrew completes a full work order (open, clock in, checklist with photos, close-out note, clock out) on an iPhone in Safari without opening a desktop. |
| Photos | 50 photos captured across two jobs, one batch shot in airplane mode, all arrive with correct capture-time GPS and timestamps, all present in the Drive mirror the next morning. |
| Estimates | A standard reroof estimate is built from assemblies in under two minutes and renders as a clean PDF at the price-book version used. |
| Coordination | A reminder rule Ivan creates himself fires to the right person, and a checklist gates a status transition as configured. |
| Communication | Every email in a finished claim file appears on that job's timeline, and each opens the correct Gmail thread. |

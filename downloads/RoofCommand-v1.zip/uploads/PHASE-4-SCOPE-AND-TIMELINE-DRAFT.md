# RoofCommand Phase 4 — Scope and Timeline

**Status:** DRAFT — approval required before product implementation

**Purpose:** Replace the superseded 10-hour/week Option 1/2/3 framework with one bounded, approval-ready Phase 4 plan at the accepted 20-hour/week / $600-weekly cap. This document does not authorize a build, external connection, client-data use, deployment, or Roofr cancellation.

## Outcome

RufCo has an owned, mobile-web-first CRM that can run one live job from intake through closeout in parallel with Roofr, with a complete accessible record and no loss of business continuity.

**Working name:** RoofCommand. This is not final branding.

## Scope boundary

### Included in Phase 4

1. **Core records and workflow**
   - Customer and contact records searchable by name, address, phone, and email.
   - Job records, including a RufCo-defined status between signed and production.
   - Job activity history and notes: who did what, when, and why.
   - Role-based access: Ivan sees all; each other user sees only the appropriate work; access can be removed promptly.

2. **Work execution**
   - Work orders with required, configurable checklists by job type/area.
   - Assigned tasks and an email-style notification format.
   - Reminders Ivan can configure and route to the responsible person.
   - Mobile-web-first screens optimized for iPhone Safari; no native iOS app in this phase.

3. **Documents and financial visibility**
   - Job document intake and attachments.
   - A fillable PDF version of RufCo's approved blank job intake/work-order form, after the source form is confirmed.
   - Conditional job-intake questions inside RoofCommand after the PDF is validated.
   - Contract total, deposit, supplements, balance owed, and depreciation-outstanding tracking.

4. **Field and communications context**
   - Per-job time clock with start/stop and required close-out note; geofence only after disclosure/consent and an implementation decision.
   - Per-customer email history.
   - CompanyCam photo/report pull-in or a documented, usable attachment/link workflow if direct integration is not technically or commercially viable within Phase 4.

5. **Ownership and usability**
   - Dark/light mode.
   - Backup/export path that gives Ivan access to his data.
   - Pilot and support materials sufficient for one real job to run in parallel with Roofr.

### Explicitly not included

- Insurance/claim pipeline, aging dashboard, permit tracking, or supplement-generation workflow (Phase 5).
- AI drafting, autonomous actions, or any email send automation (Phase 6).
- Native iOS app, crew/subcontractor rollout, or broad field/mobile expansion (Phase 7).
- Xactimate customization or write access; any later integration is read-only at most.
- Bookkeeping, payroll, tax, undisclosed employee tracking, production deployment, or external-service connection without separate approval.

## Delivery sequence and planning estimate

This is a planning estimate, not a fixed delivery promise. It assumes 20 productive hours per week, timely access to artifacts and systems, and a weekly 30-minute Ivan review. It pauses for client decisions, access delays, or new scope.

| Stage | Estimated weeks | Deliverable / approval gate |
|---|---:|---|
| A. Discovery and foundation | 1-2 | Confirm roles, job statuses, job types, pilot job, blank form, sample documents, data boundaries, and technical approach. |
| B. Core CRM | 3-6 | Customers, jobs, permissions, activity history, and mobile-first navigation ready for internal testing. |
| C. Work execution and intake | 7-10 | Work orders, checklists, tasks, reminders, fillable PDF, and conditional intake prototype. |
| D. Financial and field workflow | 11-13 | Financial fields, time-clock workflow, close-out notes, backup/export, and acceptance-test rehearsal. |
| E. Communications and photo context | 14-16 | CompanyCam and email-history approach validated, dark/light mode, pilot hardening, and launch-readiness review. |
| F. Parallel pilot | 17-20 | One real job runs in RoofCommand and Roofr for 30 days; defects and adoption issues are corrected before any Roofr cancellation discussion. |

**Planning window:** 16 build weeks plus a 4-week parallel pilot, measured from the actual Phase 4 start. The prior roadmap's Weeks 12-26 / through Week 30 remains historical until this draft is approved and dates are recalculated from kickoff.

## Decisions required before implementation

1. Approve this Phase 4 scope and delivery sequence, or identify specific additions/removals.
2. Confirm the pilot job and the people who will use it: Ivan, Joel, Javi, and Andrew.
3. Confirm job statuses, job types, checklist owners, reminder rules, and who can see financial fields.
4. Provide and validate the actual blank job intake/work-order form, one finished claim file with emails, a sample estimate, and a sample final invoice.
5. Provide approved access or exports for Google Workspace, Roofr, and CompanyCam; decide whether each integration is direct, import/export, or link/attachment-based.
6. Decide whether the time-clock geofence is needed, and if so document the employee notice and consent path.
7. Approve the data-backup/export location, retention, and pilot acceptance criteria.

## Acceptance criteria

Phase 4 is not complete merely because software is built. It is complete when:

- One agreed real job has a complete customer, job, work-order, checklist, task, document, financial, and activity record in RoofCommand.
- The assigned users can perform their role on the mobile-web interface.
- The owner can view the record, change a reminder, and export/restore the agreed data set.
- The pilot runs in parallel with Roofr for 30 days without a material recordkeeping failure.
- Ivan explicitly approves any decision to alter or cancel Roofr after the parallel pilot.

## Change control

Any new feature is recorded in a Phase 5+ backlog unless Ivan and Kadin explicitly approve a written Phase 4 scope change, its timeline impact, and any need to exceed the 20-hour/week cap. No work may exceed 20 hours or $600 in a week without Ivan's approval; no overage rate is currently set.

## Source documents

- `../../RUFCO_Scope_Charter.md`
- `../../RUFCO_Roadmap.md`
- `../../RUFCO_Decision_Log.md`
- `../../RUFCO_Next_Steps.md`


# RoofCommand: Competitive Teardown and Solution Matrix

**Date:** 2026-08-20
**Purpose:** Establish what the incumbent roofing platforms do well, what their users actually complain about, what those users keep asking for, and what RoofCommand should do differently.
**Status:** Research input. Does not authorize scope. See the scope-check section at the end.

---

## 0. The one-sentence product thesis

A roofing CRM should help you manage more jobs with less chaos. Every feature earns its place by reducing the number of places a job can silently stall, or reducing the number of taps between a person in a truck and a recorded fact.

Everything below is measured against that. Features that fail the test are noted as such, including features the incumbents charge for.

---

## 1. Market map

The roofing software market splits into four categories that overlap badly, which is the root cause of most complaints. Contractors end up paying for two or three of these and stitching them together.

| Category | What it actually is | Representative products |
|---|---|---|
| Sales/measurement front end | Aerial measurement, instant estimates, proposals, e-sign | Roofr, RoofSnap, Sunate, EagleView, HOVER |
| Full roofing CRM | Lead to job to production to invoice, insurance workflow | AccuLynx, JobNimbus, Leap (JobProgress), Dataforma, RoofLink |
| Generic field service | Scheduling, dispatch, work orders, time tracking, any trade | Zuper, Jobber, Housecall Pro, ServiceTitan |
| Photo/documentation layer | Job-site photo capture, tagging, reports | CompanyCam, CrewCam, CrewBox |

RufCo currently sits across Roofr + CompanyCam + paper + Gmail. That is the exact fragmentation this market produces.

---

## 2. Product-by-product teardown

### 2.1 Roofr (RufCo's incumbent)

**What it does well**
- Instant Estimator widget: homeowner types an address on the website, gets a ballpark number, lead lands in the pipeline already qualified. This is the strongest lead-capture pattern in the category.
- Measurement reports with a genuine free/self-measure tier, so a solo operator can start at zero cost.
- Proposals with unlimited e-signatures, invoicing, and payments included rather than sold as add-ons.
- Reviewers consistently praise speed and ease of use, and rate it strong on value versus AccuLynx.
- Published pricing at the low end: Starter free, Essentials around $209/mo, Scale around $299/mo, Instant Estimator +$125/mo, Measure+ +$95/mo.

**What users complain about**
- The CRM is shallow. No drip campaigns, no lead scoring, no intelligent follow-up sequencing, no contact segmentation. Reviewers say it will not replace a real CRM once you are running more than a handful of concurrent jobs.
- Per-report measurement pricing at roughly $13 to $19 each. Twenty quotes a month is $260 to $380 on top of subscription. It scales badly precisely as the business grows.
- Measurement accuracy complaints, specifically pitch. The difference between 7/12 and 9/12 is real money per square, and rural or tree-covered properties have satellite coverage gaps.
- Not optimized for mobile. Multiple reviewers describe the site as cumbersome on a phone.
- Integration gaps: no native Jobber or Housecall Pro integration as of April 2026, so you migrate to Roofr's CRM or run parallel and retype.
- Essentials and Scale tier pricing is not fully public; you talk to sales for current numbers.

**Wishlist implied by the complaints**
Real pipeline depth, automated follow-up, flat-rate measurements, a phone-usable interface, and an escape hatch that does not require retyping.

---

### 2.2 AccuLynx

**What it does well**
- The deepest insurance restoration tooling in the category: supplement management, Xactimate-compatible workflows, and job costing built for storm work.
- Supplier integrations (ABC Supply, Beacon) for direct material ordering, which is a genuine time sink removed.
- Offline mode in the mobile app so crews can enter data without cell service and sync later.
- Purpose-built for roofing only, so the vocabulary and the workflow match the trade instead of being bent from a generic CRM.

**What users complain about**
- Cost is the number one complaint on every review platform. Roughly $60 to $120 per user per month depending on team size, plus implementation fees commonly $500 to $1,000, with an Essential tier now published around $250/mo.
- Per-user pricing means software cost grows linearly with headcount. Reviewers repeatedly use the word "hostage."
- Nickel-and-diming: e-signatures, customer portals, and texting are paid add-ons that most contractors consider table stakes.
- The mobile app feels like a second-tier version of the web app. Missing functions, slower navigation, and more friction than the price justifies.
- Specific recurring bugs: photo scrolling position resets, weak search, occasional crashes.
- Closed API. Integrations are limited and tedious, which is deliberate lock-in.
- Search cannot filter by materials. Finding "the standing seam job in that color" is close to impossible.
- Removing the message board feature in January 2025 destroyed claim history that users depended on, which is a vendor-control problem, not a feature problem.

**Wishlist implied by the complaints**
Flat pricing not per seat, mobile parity with desktop, searchable job attributes including materials, an open API, and a guarantee that history does not disappear when the vendor changes its mind.

---

### 2.3 JobNimbus

**What it does well**
- Drag-and-drop visual job pipeline, which is the single most-praised UI pattern in the category.
- Highly customizable workflows and job statuses.
- Open API and broad native integrations, the opposite posture from AccuLynx.
- SumoQuote integration for proposals (SumoQuote was acquired by AccuLynx in 2024, so this relationship is worth watching).
- Rates 4.7 on G2 and 4.6 on Capterra across 480+ reviews, so the baseline satisfaction is real.

**What users complain about**
- The email system is the loudest complaint. One reviewer switched CRMs after missing a crucial email that turned into a BBB complaint against their company. Email that silently drops is worse than no email feature.
- Mobile apps described as bad enough that users open the desktop site on their phones instead.
- Opaque, quote-based pricing. Public figures land around a $225/mo base plus $25 to $75 per user.
- Contacts and Jobs are separate objects with the same predefined statuses, which creates persistent mix-ups.
- Storage-risk complaints serious enough that reviewers advise verifying before committing.

**Wishlist implied by the complaints**
Email that provably delivers and is provably logged, one object model instead of two competing ones, a mobile experience that is not a downgrade, and pricing you can read on a page.

---

### 2.4 ProLine

**What it does well**
- Genuinely intuitive interface with a short learning curve, which matters more than feature count for crew adoption.
- Onboarding is three or more guided calls, and support response times reported under five minutes.
- Free tier for small contractors, scaling to large operations.
- 30-day money-back guarantee tied to closing one additional job, which is a confident way to price.
- Automation-first positioning: the pitch is that the system does the follow-up so the salesperson does not have to remember.

**What users complain about**
- No AI lead scoring, no automated text/email nurture sequences, no smart follow-up recommendations. Ironically the same gap as Roofr.
- Thinner third-party integration catalog than the larger platforms.
- Per-additional-user cost gets steep for small teams.
- Pricing is not transparent, which makes budgeting during evaluation guesswork.

---

### 2.5 Zuper (generic field service)

**What it does well**
- Strong scheduling, dispatch, and work-order engine, and a 94% satisfaction rating across roughly 137 reviews.
- Configurable to many trades and workflows.

**What users complain about**
- Steep learning curve, non-intuitive UI.
- Mobile app performance issues: slow, glitchy, sync delays causing data inconsistency between field and office.
- Limited report customization.
- Non-trivial implementation, especially across complex workflows.
- Expensive relative to alternatives, with some features feeling incomplete.

**Verdict for RoofCommand:** generic field service is the wrong shape. It has no concept of a claim, a supplement, a depreciation holdback, or a pitch. Everything roofing-specific becomes a custom field, and custom fields do not enforce a workflow.

---

### 2.6 Sunate

**What it does well (per its own marketing, no independent reviews found)**
- Text-first operation. The pitch is that the whole back office runs over SMS/WhatsApp, which is how salespeople actually communicate.
- Property intelligence: query every US address in plain English filtered by roof age, permits, and storm events, and get a map back.
- Sales-grade roof reports in under 30 minutes with high-res airplane imagery, dimensions, pitch, and a 3D model.
- Homeowner instant-estimate widget priced with your own numbers, lead lands qualified.
- Free plan with paid upgrade.

**Caveat:** no third-party reviews exist yet on G2, Capterra, or the roofing review sites. Treat all of the above as claims, not verified capability. The idea worth stealing is text-first interaction, not the product.

---

### 2.7 CompanyCam (the photo layer RufCo already uses)

**What it does well**
- Every photo is auto-stamped with timestamp, GPS, user, and project, and lands in the right job folder without anyone filing it. This is the entire product and it is why people love it. 4.8 stars across 18,000+ App Store and 4,700+ Play reviews.
- Checklists assignable to users, buildable by voice, with AI organizing spoken description into a usable list.
- Photo reports: export photos plus checklist details to a branded PDF at a chosen level of detail.
- Project timeline view: scroll recent progress photos across every job.
- Public-facing website gallery, job map, and portfolio site pulled from real job photos.
- Real-time annotation on images.

**What users complain about**
- Expensive for what it is as seats grow, and it is a photo tool, not a system of record. Around $79/mo tiers and up.
- Glitches, slow photo loading, and a UI that reviewers say got harder after feature updates.
- The serious one: reports of photos vanishing, with contractors saying they lost entire jobs because the documentation was gone.

**The offline metadata trap (important, and nobody solves it well)**
Most "offline" photo apps queue the upload and then stamp GPS and time at upload, not at capture. The result: the location reads wherever the crew regained signal, and the timestamp reads the upload time. For an insurance claim or a payment dispute, wrong metadata is nearly as useless as no photo. Any RoofCommand photo capture must capture and persist the coordinate and clock reading at shutter time and treat the upload event as separate metadata.

---

### 2.8 Others worth noting

- **Leap (formerly JobProgress):** good field tools for small teams, but users report paying two to three times what they used to after acquisition-driven price hikes, plus reliability issues and thin production features.
- **RoofSnap:** fast measurement and estimate on a phone, pay-as-you-go pricing, roughly 8.6/10. Focused tool, not a platform. No pipeline, no scheduling, and accuracy drops in rural areas.
- **SumoQuote:** best-in-class visual proposals, acquired by AccuLynx in 2024, custom pricing.
- **Dataforma:** notable mostly for publishing the clearest analysis of why field service CRM adoption fails.

---

## 3. What the market says contractors actually want

Synthesized across the review and buyer-guide sources:

1. **Aerial/satellite measurement** ranks as the single most time-saving feature. Quoting three or four roofs a day from the truck instead of driving to each property changes the unit economics of the business.
2. **Fewer logins, fewer monthly charges, flat pricing.** The consistent phrasing is that contractors do not want more software, they want fewer bills and a platform that works from a truck cab.
3. **Speed on the lead.** The stated reason jobs are lost is not shingle quality, it is a lead sitting in voicemail for three days or an estimator forgetting to follow up after the inspection.
4. **Full lifecycle in one place:** lead capture, estimate, proposal, schedule, material order, crew schedule, invoice, payment, reporting.
5. **Insurance workflow that survives volume.** 40 to 60% of roof claims require at least one supplement. The money leaks because documentation is scattered across a camera roll, email threads, and memory, so the supplement never gets built and the depreciation never gets released.
6. **Data portability.** Some platforms allow only partial exports or charge for full access, exporting PDFs instead of raw data. Multi-year auto-renew agreements with termination penalties make leaving irrational.

---

## 4. Why CRM rollouts fail (the adoption research)

This matters more than the feature list, because RufCo's build succeeds or fails on whether Andrew, Joel, and Javi actually use it.

- Software designed for sales teams with IT departments and months of onboarding, deployed at a contractor with neither.
- Overcomplicated workflows with too many required fields. Manual entry, endless updates, and unnecessary reminders produce pushback. The system adds load instead of removing it.
- Insufficient or generic training. Roughly a fifth of CRM failures trace to training, and group training fails because each role needs different things.
- No leadership buy-in. If the owner does not use it, the crew will not.
- No single accountable owner per task. Things do not get done because nobody is named, not because nobody cares.
- Big-bang rollout. Deploying everything at once is cited as the number one reason rollouts stall.

**Design consequences:** minimum required fields, one screen per role, the owner using it visibly from day one, every task carrying a named owner, and a phased rollout starting with one pilot job.

---

## 5. Complaint to solution matrix

This is the core deliverable. Left column is a documented, sourced complaint about a real product. Right column is the design decision in RoofCommand that answers it.

| # | Complaint (product) | Root cause | RoofCommand solution |
|---|---|---|---|
| 1 | Per-user pricing punishes growth (AccuLynx, ProLine, CompanyCam) | SaaS seat model | Self-hosted and owned. Marginal cost of user #5 is zero. Adding Andrew costs nothing, so there is no incentive to share logins, which is what actually destroys audit trails. |
| 2 | Nickel-and-diming for e-sign, texting, portals (AccuLynx) | Add-on revenue model | Every capability built is included. No feature flags tied to billing. |
| 3 | Vendor deleted the message board and users lost claim history (AccuLynx) | Vendor controls the roadmap | Ivan owns the code and the database. Nothing is removed without his decision. Append-only activity log so history is never destructively edited. |
| 4 | Photos vanished, jobs lost (CompanyCam) | Opaque cloud storage, no user-verifiable copy | Photos stored in owned object storage plus a nightly mirror to a RufCo Google Shared Drive, foldered by job. Ivan can open a job's photos in Drive without the app existing. A job's photo count is displayed and reconciled. |
| 5 | Offline photos get GPS/time stamped at upload, not capture | Lazy metadata handling | Capture-time GPS, device clock, and user ID are written into the local record at shutter, stored in IndexedDB, and uploaded as immutable fields. Upload time is a separate field. Any photo whose capture metadata is missing is visibly flagged, not silently accepted. |
| 6 | Mobile app is a second-tier version of the web app (AccuLynx, JobNimbus, Zuper, Roofr) | Desktop-first design, mobile bolted on | Mobile web is the primary target and the only target for field roles. Desktop is the same app at a wider breakpoint. There is no "full version" that field users are missing. |
| 7 | Photo scroll position resets (AccuLynx) | State not preserved on navigation | Virtualized photo grid with scroll restoration, tested explicitly as an acceptance criterion. Small bug, high daily irritation, cheap to get right. |
| 8 | Cannot search jobs by materials or attributes (AccuLynx) | Attributes stored as free text | Structured job attributes (material type, color, profile, pitch, squares, manufacturer) as first-class indexed columns, plus full-text search across notes and documents. "Standing seam, dark bronze, 2024" returns results. |
| 9 | Email silently failed, missed message caused a BBB complaint (JobNimbus) | Fire-and-forget email, no delivery record | Email is read and threaded via the Gmail API against the account of record. Every message is logged with its Gmail message ID, thread ID, and timestamp. Nothing is "sent by the CRM" in Phase 4; it links to the real Gmail thread, so the source of truth stays where deliverability is already proven. |
| 10 | Contacts and Jobs are separate objects with identical statuses, causing mix-ups (JobNimbus) | Duplicated state machine | One pipeline. Status lives on the Job only. A Customer has no status; it has jobs. A property/address is its own entity so repeat work at the same roof is linked. |
| 11 | Shallow pipeline, no follow-up automation (Roofr, ProLine) | Sales-tool origins | Every job carries a next action, an owner, and a due date. A job with no next action is surfaced as an exception on the owner dashboard. This is a data-integrity rule, not a nurture campaign. |
| 12 | $13 to $19 per measurement report (Roofr) | Per-transaction pricing | Out of scope to replicate. RoofCommand records measurements (manual entry, or a report file attached from whatever measurement source is used) rather than generating them. Do not try to beat EagleView. Store the numbers, use them everywhere. |
| 13 | Measurement pitch errors on rural/tree-covered roofs (Roofr) | Satellite limits | Measurement fields carry a source and a confidence flag (satellite, hand measured, adjuster scope). Estimates built from unverified satellite numbers are visibly marked. |
| 14 | Opaque pricing, must call sales (Roofr, JobNimbus, ProLine) | Sales-led motion | Not applicable to an owned system, but the analogous rule: no hidden operating cost. Monthly infrastructure cost is documented in the repo and reviewed quarterly. |
| 15 | Closed API, integrations tedious (AccuLynx) | Deliberate lock-in | Documented REST API and a full JSON/CSV export of every table on demand. Export is a tested feature, not a support ticket. |
| 16 | Partial exports, PDF-only exports, export paywalls (industry-wide) | Lock-in economics | One-click full export: all records as CSV plus all files with a manifest mapping file to job. Verified restorable, same standard as the Phase 0 backups. |
| 17 | Steep learning curve, non-intuitive UI (Zuper) | Feature breadth over role focus | Role-shaped home screens. Andrew opens the app and sees today's work orders and a clock-in button, nothing else. Ivan sees the exception dashboard. |
| 18 | Too many required fields, system adds work (adoption research) | Requirements gathering without field observation | Hard rule: creating a job requires name, address, phone, job type. Everything else is optional until a status transition demands it. Checklists gate status changes, forms do not gate data entry. |
| 19 | Supplements never built, depreciation never released (industry-wide) | Documentation scattered across camera roll, email, and memory | Claim entity with its own status machine and aging clock. Every claim shows days in current status and dollars outstanding. Photos, adjuster emails, and scope documents attach to the claim, not just the job. (Phase 5, specced now so Phase 4 data model supports it.) |
| 20 | Crews abandon apps the first time they lose signal | Cloud-dependent design | Offline-tolerant: cached job list, queued photo uploads, queued checklist entries and clock events, with a visible sync indicator and a queue count. Honest caveat in the architecture doc about iOS PWA storage eviction. |
| 21 | Rollout stalls because everything deployed at once | Big-bang deployment | One pilot job, four roles, 30 days parallel with Roofr, per the approved Phase 4 acceptance criteria. |
| 22 | Owner does not use it so the crew does not either | No leadership buy-in | The morning exception dashboard is built for Ivan first and is the first screen delivered. If he opens it daily, adoption follows. |

---

## 6. What NOT to build (deliberate non-goals)

Stating these protects the timeline more than any feature list does.

- **Aerial measurement generation.** EagleView, HOVER, and Roofr have satellite pipelines and per-report economics. Record the numbers, attach the report, do not compete.
- **Xactimate integration beyond read-only.** Already out of scope in the charter. Do not touch its data.
- **Nurture/drip marketing campaigns.** The complaint that Roofr and ProLine lack these comes from high-volume storm chasers. RufCo's problem is stalled claims, not top-of-funnel volume.
- **A native iOS app in Phase 4.** Confirmed direction is mobile web first, iPhone Safari optimized.
- **Public portfolio site generated from job photos.** CompanyCam does this well and it is a marketing feature, not a chaos-reduction feature. Phase 3 website work can link to it if wanted.
- **Material ordering integrations (ABC Supply, Beacon).** High value, but these are partner-gated APIs. Backlog item, not a build item.
- **Lead scoring and AI follow-up recommendations.** Phase 6 at the earliest, and only on clean data.

---

## 7. Scope check against the approved Phase 4 boundary

Per RUFCO_Project_Instructions rule 1, flagging drift explicitly rather than building through it. Three of the six feature areas requested sit partly outside the current Phase 4 scope draft.

| Requested area | Phase 4 status | Assessment |
|---|---|---|
| Visual job pipeline | **In scope.** Covered by "job records, including a RufCo-defined status between signed and production." | Build it. |
| Mobile-first design | **In scope.** "Mobile-web-first screens optimized for iPhone Safari." | Build it. |
| Team coordination | **In scope.** Work orders, checklists, assigned tasks, reminders, role-based access. | Build it. |
| Customer communication history | **Mostly in scope.** "Per-customer email history" is listed. SMS/call logging is not. | Build email history. SMS logging goes to Phase 5+ backlog, and depends on Phase 2 RingCentral anyway. |
| Photo documentation (CompanyCam parity) | **Partly out of scope.** Phase 4 says "CompanyCam photo/report pull-in **or** a documented attachment/link workflow." In-app capture, annotation, auto-tagging, and generated photo reports are materially more than pull-in. | Requires a written Phase 4 scope change, or split: build capture + auto-metadata + job attachment in Phase 4 (it is the cheapest path and removes the CompanyCam bill), defer annotation and branded photo reports to Phase 5+. **Ivan's decision.** |
| Quick estimates and invoicing | **Partly out of scope.** Phase 4 covers financial *visibility* (contract total, deposit, supplements, balance, depreciation outstanding). It does not cover generating estimates or issuing invoices. | Requires a written Phase 4 scope change. Recommended split: build the line-item estimate record and PDF output in Phase 4 (it feeds supplements in Phase 5), defer payment collection and e-sign to Phase 5+. **Ivan's decision.** |

Nothing above should be built until Ivan approves the Phase 4 scope draft and, if he wants the two flagged areas, signs off on the timeline impact. Estimated added build time for both flagged areas at the reduced split: roughly 3 to 4 weeks on top of the current 16-week planning window.

---

## Sources

- [Roofr Review 2026 (BuilderLync)](https://builderlync.com/blog/roofr-review-pricing-features-alternatives)
- [Roofr Review 2026 (Roofing Software Guide)](https://roofingsoftwareguide.com/reviews/roofr-review/)
- [Roofr Pricing: Free vs Paid Plans 2026](https://roofingsoftwareguide.com/reviews/roofr-pricing/)
- [Roofr Reviews (Capterra)](https://www.capterra.com/p/208102/Roofr/reviews)
- [Roofr Pricing Details, Pros & Cons (Software Connect)](https://softwareconnect.com/reviews/roofr/)
- [AccuLynx Review 2026 (BuilderLync)](https://builderlync.com/blog/acculynx-review-pricing-features-2026)
- [AccuLynx Review 2026 (Roofing Software Guide)](https://roofingsoftwareguide.com/reviews/acculynx-review/)
- [AccuLynx Pricing: Full Breakdown & Hidden Costs](https://roofingsoftwareguide.com/guides/acculynx-pricing/)
- [AccuLynx Reviews (Capterra)](https://www.capterra.com/p/116187/Acculynx/reviews/)
- [AccuLynx Pricing 2026 (Projul)](https://projul.com/blog/acculynx-pricing-breakdown/)
- [JobNimbus Reviews (Capterra)](https://www.capterra.com/p/126797/JobNimbus/reviews/)
- [JobNimbus Review 2026 (Roofing Software Guide)](https://roofingsoftwareguide.com/reviews/jobnimbus-review/)
- [JobNimbus Pricing 2026 (Projul)](https://projul.com/blog/jobnimbus-pricing-analysis-2026/)
- [AccuLynx vs JobNimbus 2026](https://roofingsoftwareguide.com/comparisons/acculynx-vs-jobnimbus/)
- [ProLine CRM Review (BuilderLync)](https://builderlync.com/blog/proline-crm-review-alternatives)
- [ProLine vs Other Roofing CRMs](https://useproline.com/proline-vs-other-roofing-crms/)
- [Zuper Pros and Cons (G2)](https://www.g2.com/products/zuper/reviews?qs=pros-and-cons)
- [Zuper Reviews (Capterra)](https://www.capterra.com/p/197014/Zuper/reviews/)
- [Zuper Review 2026 (Research.com)](https://research.com/software/reviews/zuper)
- [Sunate](https://www.sunate.app/)
- [CompanyCam Advanced Features](https://companycam.com/advanced-features)
- [CompanyCam Checklists](https://companycam.com/advanced-features/checklists)
- [CompanyCam Reports](https://companycam.com/advanced-features/reports)
- [CompanyCam Reviews (Capterra)](https://www.capterra.com/p/171143/CompanyCam/reviews/)
- [CompanyCam Reviews (Trustpilot)](https://www.trustpilot.com/review/companycam.com)
- [Offline Photo Documentation for Field Crews (CompanyCam)](https://companycam.com/resources/blog/offline-photo-documentation-for-field-crews)
- [Offline Construction App Guide 2026](https://www.scanmanifold.com/blog-posts/offline-construction-app-guide)
- [What Roofing Contractors Actually Want in CRM Software 2026](https://myquoteiq.com/what-roofing-contractors-want-in-crm-software/)
- [Roofing Insurance Supplements: 2026 Guide (IA Solutions)](https://www.iasolutions.claims/blog/roofing-insurance-supplements-2026-guide-independent-adjusters)
- [Best Roofing Insurance Supplement Software (ProLine)](https://useproline.com/best-roofing-insurance-supplement-software-for-contractors/)
- [Why Field Service CRM Adoption Fails (Dataforma)](https://www2.dataforma.com/why-field-service-crm-adoption-fails-how-fix/)
- [Roofing Crew Software Adoption Guide](https://roofingsoftwareguide.com/guides/roofing-crew-software-adoption-guide/)
- [How to Switch Roofing CRMs Without Losing Data](https://roofingsoftwareguide.com/guides/how-to-switch-roofing-crm-without-losing-data/)
- [Top Roofing Estimating Software 2026 (RoofSnap)](https://roofsnap.com/blog/best-roofing-software/)
- [RoofSnap Review 2026](https://roofingsoftwareguide.com/reviews/roofsnap-review/)

# AGENTS.md — RoofCommand

Operating rules for Codex, Claude Code, and any other agent working in this repository.

Read this file, then `docs/DATA-MODEL.md` and `docs/PERMISSIONS.md`, before writing code.

---

## 1. What this is

RoofCommand is the CRM for RufCo Construction LLC (Amarillo TX, roofing and construction). It replaces Roofr, CompanyCam, and paper for job tracking, work execution, photo documentation, and money visibility. Ivan Mata owns the code, the data, and every account.

**Product thesis:** help RufCo manage more jobs with less chaos. A feature earns its place by reducing the number of places a job can silently stall, or reducing taps between a person in a truck and a recorded fact. If a proposed change does neither, say so instead of building it.

**Primary user surface is a phone.** Mobile web, iPhone Safari, installed as a PWA. Desktop is the same app at a wider breakpoint. There is no separate "full version."

---

## 2. Hard rules

1. **Do not build outside the approved scope.** The authoritative scope is `../../RUFCO_Scope_Charter.md` and `PHASE-4-SCOPE-AND-TIMELINE-DRAFT.md`. If a request falls outside it, stop and say so in the PR description. New ideas go to the Phase 5+ backlog in `ROADMAP-Build-Plan.md`, not into the build.
2. **Never connect external services, use real client data, or deploy without explicit written approval.** Local development uses seeded fake data only.
3. **Never open, read, or edit credential files.** No `.env`, no `*secret*`, no keys or tokens. If a task appears to require one, stop and ask.
4. **Never send email, SMS, or any outbound message.** Phase 4 reads Gmail. It does not send. Phase 6 sending is approval-gated and does not exist yet.
5. **Feature branches and pull requests only.** Never commit to `main`.
6. **Do not claim work is done without evidence.** Paste the passing test output or the command result. If you could not verify something, say plainly that you could not.
7. **Do not weaken a test to make it pass.** Fix the code. If the test is genuinely wrong, change it in its own commit with the reasoning in the message.
8. **Append the handoff note to `../../codex-log.md`** when a Rufco task is complete.

---

## 3. Stack

| Layer | Choice |
|---|---|
| Client | React 19, TypeScript, Vite, `vite-plugin-pwa`, Tailwind CSS, TanStack Query, Dexie |
| Server | Node 22, Fastify, TypeScript, Zod |
| Database | PostgreSQL 17, Drizzle ORM, drizzle-kit migrations |
| Files | MinIO (S3-compatible), nightly mirror to a Google Shared Drive |
| Auth | Google OAuth, `hd` restricted to `rufcollc.com`, plus a database allowlist |
| Queue | pg-boss (Postgres-backed). No Redis. |
| Proxy | Caddy |
| Deploy | Docker Compose, single Linux host |

Rationale is in `DECISION-Stack-and-Architecture.md`. Do not swap any of these without a logged decision.

---

## 4. Layout

```
packages/shared    Zod schemas, shared types, enums, permission matrix
packages/api       Fastify server, Drizzle schema, migrations, pg-boss handlers
packages/web       Vite React PWA
ops/               backup.sh, restore-verify.sh
docs/              DATA-MODEL.md, PERMISSIONS.md, RUNBOOK.md
```

Types and validation schemas live in `packages/shared` and are imported by both sides. A field rename must break the build, not production.

---

## 5. Non-negotiable invariants

These are enforced in the database, not only in application code. Do not remove or weaken the triggers.

- **`activity` is insert-only.** No update, no delete. Corrections are new rows.
- **Photo capture metadata is immutable.** `photos.captured_at`, `captured_lat`, `captured_lng`, `captured_by` are set at insert and never updated. `uploaded_at` is a separate field. Never backfill a capture location from an upload location. If GPS was unavailable at shutter, set `location_verified = false` and show the badge. This is the difference between a photo that supports an insurance claim and one that does not.
- **Nothing is hard deleted.** Every table soft deletes with `deleted_at` so an export is always complete.
- **Permissions are enforced server side** in one middleware backed by `packages/shared/permissions.ts`. The UI hiding a control is not access control. Every endpoint needs a permission test per role.
- **Status lives on the Job only.** Customers have no status. Do not add one.
- **Originals are never modified.** Thumbnails and any future annotations are derived artifacts stored separately.
- **Every job has a next action with an owner and a due date,** or it appears on the exception dashboard as a defect.

---

## 6. Code conventions

- TypeScript strict mode, no `any`, no non-null assertions without a comment explaining why.
- Zod at every boundary: request bodies, query params, and external API responses.
- Drizzle queries in `src/db/queries/`, route handlers stay thin. Business logic in `src/services/`.
- Migrations are plain SQL reviewed in the PR. Never edit a migration that has run anywhere.
- Errors: typed error classes, mapped to HTTP status in one place. Never leak a stack trace to a client.
- Money is stored as integer cents. Never floats.
- Timestamps are `timestamptz`, stored UTC, rendered in America/Chicago.
- Component files under 200 lines. Extract rather than nest.
- No new dependency without justification in the PR description. Prefer the standard library.

---

## 7. Mobile and offline rules

- Primary actions in the bottom third of the screen. Bottom tab bar, not a hamburger.
- Minimum 44px touch targets.
- Every list is virtualized and restores scroll position on back navigation. This is an acceptance test, not a nicety.
- No horizontal page scroll. The pipeline board's column swipe is the one deliberate exception.
- **Offline-tolerant, not offline-first.** iOS Safari has no Background Sync API and can evict script-writable storage after roughly seven days of disuse. Queued items flush when the app is next opened online. Never build UI that promises silent background upload.
- The sync state chip is always visible and always accurate: `Synced` or `N items queued`, tappable to list the queue. Nothing syncs silently and nothing fails silently.
- Request the Persistent Storage API on install. Upload aggressively whenever a connection exists. Never treat the device as the only copy of a photo past one working day.

---

## 8. Testing

- Unit tests for services, permission checks, the status machine, and money math.
- Integration tests against a real Postgres in Docker, not a mock.
- Every permission rule has a test that asserts a forbidden role gets a 403 from the API directly.
- Offline queue has tests for enqueue, flush, partial failure, and retry.
- CI runs typecheck, lint, unit, and integration on every PR. A red CI is not merged.
- Before opening a PR, run the full suite and paste the result in the description.

---

## 9. Pull request format

```
## What
One or two sentences.

## Scope check
Which approved Phase 4 scope item this implements. If it implements nothing in the
approved scope, stop and flag it instead of opening the PR.

## Evidence
Test output, migration output, or a screenshot. Required.

## Risk
What could break, and what is not covered.
```

---

## 10. When to stop and ask

- The task implies a feature not in the approved Phase 4 scope
- The task requires real client data, a live credential, or an external service connection
- The task requires deploying, or touching anything in production
- A test is failing for a reason you do not understand
- An invariant in section 5 appears to be in the way

Stopping and asking is correct behavior here, not a failure. This is a client engagement with a fixed weekly cap and a client who is traveling and often unreachable. Wrong work built confidently costs more than a paused ticket.

# RoofCommand: Stack and Architecture Decision

**Date:** 2026-08-20
**Decision owner:** Kadin (technical), Ivan (cost and ownership)
**Status:** Recommendation, pending approval. Log to `RUFCO_Decision_Log.md` once accepted.

---

## Constraints that drove this

| Constraint | Source |
|---|---|
| Ivan owns all deliverables, code, data, and accounts | Scope Charter, pricing terms |
| Mobile-web-first, iPhone Safari optimized, no native app in Phase 4 | Roadmap update 2026-08-19 |
| Self-hosted and/or Google-native storage; RufCo is on Google Workspace | Kadin, 2026-08-20 |
| Google Workspace is retained, M365 dropped | Decision 2026-08-19 |
| One maintainer at 20 hrs/week, W-2 job search stays first | Scope Charter |
| Photo-heavy, must tolerate poor signal in the field | Phase 4 scope, field reality |
| Backup and export path Ivan can use himself | Phase 4 scope |
| Built with Codex in a private GitHub repo, feature branches and PRs | `PROJECTS/RoofCommand/CLAUDE.md` |

The binding constraint is not technical, it is **maintenance capacity**. One person at 20 hours a week, who is also job hunting, cannot maintain a stack with many moving parts. Every choice below optimizes for fewest components that still meet the requirements.

---

## Recommendation

```
Client    React 19 + TypeScript + Vite, PWA (vite-plugin-pwa), Tailwind CSS
          TanStack Query for server state, Dexie (IndexedDB) for the offline queue
Server    Node 22 + Fastify + TypeScript, REST, Zod schemas shared with the client
Data      PostgreSQL 17, Drizzle ORM + drizzle-kit migrations
Files     MinIO (S3-compatible) on the same host, nightly mirror to Google Shared Drive
Auth      Sign in with Google, restricted to the rufcollc.com Workspace domain
Jobs      pg-boss (Postgres-backed queue). No Redis.
Proxy     Caddy (automatic TLS)
Deploy    Docker Compose on one Linux host, GitHub Actions builds the image
Backups   Nightly pg_dump + MinIO sync, encrypted, to a RufCo Google Shared Drive
```

Total moving parts in production: **four containers** (app, postgres, minio, caddy). That is the point.

---

## Why each choice, and what was rejected

### Frontend: React SPA + Vite PWA, not Next.js

**Chosen because:**
- Every screen is behind a login. There is no SEO surface and no anonymous first paint to optimize, so server-side rendering buys nothing here.
- An SPA shell is dramatically simpler to make offline-capable. One cached shell, one service worker, deterministic behavior.
- Self-hosting a Vite build is copying static files. Self-hosting Next.js means standalone output, image optimization config, and a Node server whose behavior differs between dev and prod. That is maintenance cost for zero benefit in this app.
- Codex works well with a clean client/server split. The API boundary is explicit, which produces better generated code than server actions blurring the line.

**Rejected: Next.js.** Good default for public-facing apps. Wrong default for an authenticated offline-tolerant field tool that one person maintains.

**Rejected: React Native / Expo.** The direction is already decided: mobile web first, native only if truly needed. Adding an app-store release cycle to a solo build is a schedule risk with no Phase 4 payoff.

### PWA, with honest limits

Installed to the iPhone home screen it looks and launches like an app. The limits, verified current as of 2026:

- **Background Sync API is not supported on iOS Safari.** Queued uploads flush when the app is next opened and online, not in the background. The UI must therefore make the queue visible and tell the user to open the app on wifi. Do not promise silent background upload.
- **Storage eviction.** Safari can clear script-writable storage (IndexedDB, Cache API) if the PWA is not used for roughly seven days, and iOS can clear PWA storage after a few weeks of disuse. Mitigation: request the Persistent Storage API on install, upload aggressively whenever a connection exists, and never treat the device as the only copy of a photo for longer than one working day.
- Storage quota itself is not the problem post-Safari 17 (up to 60% of disk per origin), the eviction policy is.

**Consequence for the pilot:** offline-tolerant is achievable and honest. Offline-first, where a crew works a full day with no signal and trusts the phone to hold 200 photos, is not something to promise on iOS web. If that becomes a real requirement after the pilot, the answer is a thin Capacitor wrapper around the same codebase, which is a Phase 7 decision, not a rewrite.

### Backend: Fastify + TypeScript

Small, fast, first-class TypeScript, schema validation built in. Zod schemas are shared between client and server so a field rename breaks the build instead of breaking production. Codex generates predictable Fastify route code.

**Rejected: Google Apps Script + Sheets.** Zero hosting cost and native Gmail/Drive access are genuinely attractive, and it was on the table. It fails on three hard requirements: photo-heavy mobile UX is poor, Sheets is not a database once jobs, photos, line items, and activity logs are involved (concurrent writes and referential integrity both break down), and execution quotas will be hit. It also cannot deliver an installable offline-tolerant PWA. Good tool for the Gmail Assistant work, wrong tool for the CRM.

**Rejected: Supabase.** Excellent developer experience, and it was the default recommendation before the self-hosted constraint. Managed Supabase conflicts with "self-hosted and owned." Self-hosted Supabase is roughly nine containers to maintain, which is worse than the four above for a solo maintainer. Postgres directly gives the same database without the surface area.

**Rejected: Firebase.** Vendor lock-in on the data model is the exact complaint the whole product is designed against.

### Database: PostgreSQL + Drizzle

Postgres because the data is deeply relational (customer, property, job, work order, checklist item, photo, line item, payment, claim) and because full-text search, JSONB for the conditional-intake answer sets, and PostGIS-lite geo queries are all available without another service.

Drizzle over Prisma: lighter runtime, SQL-first so generated code is auditable, no separate query engine binary, and migrations are plain SQL files that can be reviewed in a PR.

### Auth: Sign in with Google, domain-restricted

RufCo is on Google Workspace and staying. Using Google as the identity provider means:
- No passwords stored, no password reset flow to build, no credential breach surface.
- MFA is whatever Workspace enforces, which Phase 1 is already hardening.
- Offboarding is real: suspend the Workspace account and CRM access dies. That satisfies "access can be removed promptly" without a second offboarding checklist.
- `hd` claim restricted to `rufcollc.com`, plus an explicit allowlist of user records in the database. Being in the domain is necessary, not sufficient.

Sessions: httpOnly, Secure, SameSite=Lax cookie holding an opaque session ID, sessions table in Postgres so revocation is immediate.

### File storage: MinIO primary, Google Drive mirror

This is the hybrid answer to "self-hosted and/or Google native."

**MinIO as primary** because photo workloads need presigned URLs, byte-range reads, and a thumbnail pipeline. Drive as a primary photo store means per-file API latency, quota exposure (750 GB/day upload cap per user, and API quotas were revised as of 1 May 2026), and a permissions model that fights role-based access.

**Google Shared Drive as the durable mirror** because it directly answers the loudest complaint in the research: contractors losing photos with no independently verifiable copy. Nightly job writes originals to `RufCo Jobs / {Job Number} {Address} / Photos / {YYYY-MM-DD}/` plus a per-job metadata CSV. Ivan can open any job's photos in Drive with the app switched off. Storage is available: Business Standard pools 2 TB per user across the org.

Photo pipeline: upload original → store immutable → generate 300px and 1200px derivatives with sharp → serve derivatives via presigned URLs. Originals are never modified.

### Background jobs: pg-boss

Mirroring to Drive, thumbnail generation, reminder evaluation, aging checks, and nightly reconciliation all need a queue. pg-boss runs inside Postgres, so there is no Redis container, no second persistence story, and no extra thing to back up.

### Hosting: see the dedicated analysis below

Hosting is the one decision that also decides the programming language, so it must be closed before Stage A writes code. Full options analysis in the next section.

---

## Hosting analysis: can RoofCommand live on the rufcollc.com website?

**Question asked (2026-08-20):** put the app and its database on the existing rufcollc.com website hosting, so the system runs with no subscriptions to outside services and nothing external built in.

**Short answer:** the application code and the database can live there. The photos cannot. Photo storage is what breaks it, and photos are the point.

### First, a definitions correction worth making before Ivan hears a number

The website hosting is itself a subscription. So is the domain. So is Google Workspace. Moving the CRM onto GoDaddy does not remove subscriptions, it consolidates them. That is still a real win, but it is a different win than the one being aimed at, and stating it plainly now avoids a bad conversation later.

The goals that are actually achievable, and worth stating as the real target:

- **No per-seat pricing.** Adding Andrew costs zero, forever.
- **No feature paywalls.** No add-on fee for e-signature, texting, or a portal.
- **No vendor able to delete a feature or the data.** Ivan owns the code and the database.
- **No new vendor relationship.** Use what RufCo already pays for.
- **Full portability.** Everything exports, always, and the system can be lifted to different hardware in a day.

Every option below delivers all five. They differ on cost shape and on what breaks when something goes wrong.

### The blocking math on shared hosting

Verified GoDaddy Web Hosting (cPanel) limits, current as of 2026:

| Limit | Value |
|---|---|
| Disk, by plan | Economy 25 GB, Deluxe 50 GB, Ultimate 75 GB, Maximum 100 GB |
| Hard ceiling, all plans | 100 GB, stated in the Hosting Agreement regardless of "unlimited" marketing |
| Inodes (files and folders) | 250,000 per Linux account |
| Concurrent MySQL connections | 30 |
| SMTP relays | 500/hour |
| SSH | Deluxe and above |
| Acceptable use | Prohibits storing "backups of content from another computer or website" |

Now RufCo's actual photo load. A photo-heavy roofing job runs 100 to 300 photos. Call it 200 photos and 400 MB of originals per job, at roughly 15 jobs a month.

**Disk:** ~6 GB/month, ~72 GB/year. Year one exceeds Deluxe. Year two exceeds the 100 GB hard ceiling on every plan, including "unlimited."

**Inodes, which is the sharper blade:** each photo is three files (original, 300px thumb, 1200px view). 3,000 photos/month × 3 = 9,000 files/month, roughly **108,000 files per year**. A Laravel install with its vendor directory is 15,000 to 30,000 inodes. An existing WordPress site is another 30,000 to 50,000. That leaves roughly 170,000 to 200,000 for photos, so the account hits the cap somewhere around **month 20**, and GoDaddy throttles or suspends at the cap. There is no plan upgrade that fixes it, because the inode cap is per account, not per plan.

**And the AUP:** using the hosting account as the photo archive is arguably the prohibited "bulk storage" use. Being technically over a line in a hosting agreement is a bad place to keep the evidence for insurance claims.

**Node.js is also out on shared hosting.** GoDaddy shared plans expose Node in cPanel but restrict processes aggressively enough that a real long-running server is not viable. Choosing shared hosting means the whole stack becomes PHP.

### The three real options

| | **A. Existing GoDaddy shared hosting** | **B. GoDaddy VPS** | **C. Office server** |
|---|---|---|---|
| Language | PHP 8.3 / Laravel + MySQL | Node stack as specced | Node stack as specced |
| Recurring cost | $0 new (already paid) | ~$9/mo intro on a 36-month prepay, roughly $18 to $25/mo at renewal | **$0** |
| One-time cost | $0 | $0 | ~$600 to $900 (mini PC, 2 TB NVMe, UPS) |
| Photo capacity | **~20 months, then a wall** | 160 GB to 1.5 TB, sized to fit | 2 TB, effectively unlimited for this business |
| Background jobs | Cron only, minute granularity | Full | Full |
| Goes down when | GoDaddy has an incident, or a WordPress update on the same account breaks something | GoDaddy has an incident | Office loses power or internet |
| Who fixes it | GoDaddy support | Kadin, remotely | Kadin, **on site** |
| Vendor count | 1 (already there) | 1 (already there) | 0 paid, 1 free (tunnel provider) |
| Verdict | Viable pilot, not a destination | Safe, boring, costs money | Only true zero-recurring answer |

**On Option A being a "viable pilot":** it genuinely is. Laravel on cPanel with MySQL, queues on the database driver fired by cron, and photos on local disk would run the Stage F pilot fine, because one pilot job is a few hundred photos. The problem is that it fails in year two, and migrating a live CRM off a platform later is exactly the pain this whole project exists to escape. Building the thing twice at $30/hour is the most expensive option on the page.

**On Option C, the honest version.** This is the only answer that matches the stated goal, and the storage math strongly favors it. It works like this: a mini PC in the RufCo office running the same four containers, reached from the field through a Cloudflare Tunnel (free tier, no static IP, no port forwarding, TLS handled), with nightly encrypted backups to the Google Shared Drive RufCo already pays for. No new bill, ever. 2 TB holds roughly 25 years of photos at RufCo's rate.

Its two real risks, stated plainly rather than buried:

1. **Availability.** If the office loses power or internet, the CRM is down for everyone in the field. A UPS covers a blip, not an outage. Counterpoint worth weighing: when the office internet is down the office is already largely stopped, and the offline-tolerant design means crews can still capture photos, run checklists, and clock in and out, queued, exactly as if they had no signal.
2. **On-site dependency.** Kadin has to physically be there for hardware failures. During the engagement that is fine. After it, it is a real question about who Ivan calls.

Cloudflare Tunnel is technically an external dependency, which cuts against "independent of external software." It is free, replaceable by a static IP from the ISP (usually a paid add-on), and the alternative is exposing the office router to the internet, which is worse. Worth naming rather than pretending otherwise.

### Recommendation

**Option C (office server) if Ivan's priority is genuinely zero recurring cost, and he accepts that an office internet outage takes the CRM offline. Option B (GoDaddy VPS) if he wants it always reachable and is fine with roughly $20 a month for that.**

Not Option A as the destination. It is buildable and it would demo well, and it hits a wall in under two years with all of RufCo's job history inside it.

There is also a middle path if Ivan wants both: build on Option C, and keep the VPS as the documented one-day failover. Because the stack is four containers plus a Postgres dump and a file sync, restoring to a VPS is a runbook step, not a project. That optionality is worth designing for regardless of which he picks.

### One structural note either way

**Do not put the CRM inside the marketing site's hosting account, even if the app were PHP.** Put it on `app.rufcollc.com` pointing at whichever server wins. Reasons: the marketing site is Phase 3 work with unresolved SKP Creative ownership questions, a WordPress or theme update should never be able to take the CRM down, and the two have completely different backup and uptime needs. Keeping them separate costs nothing and removes an entire class of outage.

### What is still unknown

RufCo's actual hosting plan has not been seen. It may be cPanel hosting, Managed WordPress (which cannot host a custom app at all), or Website Builder (same). This is blocked on the GoDaddy credential handoff from Ivan, which is already on the Next Steps list. **The hosting decision cannot be finalized until that access exists**, but the analysis above holds regardless of which plan turns out to be there.

### Monthly running cost, by option (to be confirmed, not a quote)

| Item | Option A | Option B | Option C |
|---|---|---|---|
| Server | $0 (existing) | ~$18 to $25 | $0 |
| Hardware, one time | $0 | $0 | ~$600 to $900 |
| Domain/DNS | already owned | already owned | already owned |
| Google Workspace storage | already paid | already paid | already paid |
| TLS | $0 | $0 (Caddy + Let's Encrypt) | $0 (tunnel-terminated) |
| **New recurring** | **$0** | **~$20/mo** | **$0** |

Against Roofr Essentials at ~$209/month plus per-report fees, plus CompanyCam. Do not present any of this as savings to Ivan until the pilot proves parity, and do not cancel either vendor before the 30-day parallel run passes.

---

## Using Google Workspace to remove the constraints

**This changes the hosting answer.** RufCo already pays for Google Workspace Business Standard, which pools 2 TB per user. At roughly five accounts that is about 10 TB of storage already bought and sitting unused. RufCo's entire photo load is ~72 GB/year, which is under 1% of the pool per year.

### The design move that unlocks it: separate the metadata from the bytes

The reason shared hosting failed was file count, not information volume. So stop keeping files on the host.

| Layer | Where it lives | Growth on the host |
|---|---|---|
| All metadata (who, when, where, tags, job links) | MySQL/Postgres on the host | Rows, not files. Trivial. |
| Original photo, permanently | Google Shared Drive | Zero |
| Derivatives (300px thumb, 1200px view) | Google Shared Drive | Zero |
| Recently viewed derivatives | **Bounded LRU cache on the host, hard-capped at ~20,000 files** | **Flat, forever** |

The cache has a fixed file-count ceiling and evicts the oldest entries. That makes the host's disk and inode usage a **constant instead of a growth curve**, no matter how many photos exist. Ten years of job history uses the same number of inodes as month one.

**Redone inode math:** app code and vendor directory ~30,000, existing site ~40,000, photo cache capped at 20,000. Total ~90,000 against a 250,000 cap, and it never grows. The month-20 wall disappears.

Upload path: the phone posts to the app, the app writes to the cache and returns immediately so the photo is visible at once, then a queued job pushes the original and derivatives to Drive and records the `drive_file_id`. The user never waits on Google.

**The service-account gotcha, stated precisely because it is where this normally breaks:** since June 2023 service accounts get a 0 GB storage quota, so a service account cannot write to its own My Drive. Files written into a **Shared Drive** count against the organization's pooled storage instead, which is the whole point. RoofCommand must therefore write to a Shared Drive owned by RufCo, never to a service account's own space.

### What each Google service resolves

| Service | Problem it removes | Cost | Status |
|---|---|---|---|
| **Shared Drive (Drive API)** | Photo and document storage, the hard blocker on shared hosting. Also gives Ivan a copy he can open with the app switched off, which answers the "CompanyCam lost our photos" complaint directly. | Already paid | **Recommended, changes the hosting decision** |
| **Drive as backup target** | Offsite backup for the database dump, encrypted, nightly | Already paid | Already in the plan |
| **Gmail API (read)** | Per-customer email history without becoming a mail server | Already paid | Already in the plan |
| **Gmail API (send)** | Work-order and reminder notifications. Sidesteps the 500 SMTP relays/hour shared-hosting cap entirely, and deliverability becomes Google's problem rather than a shared IP's. Workspace allows 2,000 recipients/day; RufCo will use maybe 20 to 50. | Already paid | **Recommended** |
| **Google OAuth** | No password storage, no reset flow, MFA inherited from Phase 1, and offboarding that actually works | Already paid | Already in the plan |
| **Google Calendar API** | Work orders pushed to the assigned person's calendar, so Andrew sees tomorrow's jobs in the app he already opens. Genuinely the cheapest adoption win available. | Already paid | **Phase 5+ backlog** (not in approved Phase 4 scope) |
| **Google Sheets export** | One-click export writes a Sheet Ivan can open, instead of a CSV download he has to do something with | Already paid | **Phase 5+ backlog**, small |

### Ruled out, with reasons

- **Google Apps Script + Sheets as the whole backend.** Still no. Sheets is not a database once jobs, line items, photos, and an activity log exist, concurrent writes and referential integrity both fail, and execution quotas bite. Fine for the Gmail Assistant work, wrong for the CRM.
- **Google Photos API.** Access was restricted in 2025 so apps can generally only touch content they created. Wrong tool regardless.
- **Google Cloud Run + Cloud SQL.** Cloud Run has a real free tier, but Cloud SQL does not, and this creates a new billing relationship with usage-based charges. That is the opposite of the stated goal.

### New risks this introduces, stated plainly

1. **Drive becomes a hard dependency for full-size photos.** If Google Drive is down, thumbnails still serve from cache and new uploads queue, but originals are briefly unreachable. Google's Drive availability is better than any alternative on the table, including a box in the RufCo office.
2. **Drive API quotas.** Well inside limits at RufCo scale (750 GB/day upload cap versus ~200 MB/day actual), but the client needs exponential backoff on 403 rate responses, not naive retries.
3. **Quota billing change.** Google has signaled that exceeding Drive API quota request limits will incur Google Cloud billing charges later in 2026. RufCo will be far under, but this goes on the quarterly review checklist rather than being assumed permanent.
4. **Deletion outside the app.** Someone with Shared Drive access could delete originals. Mitigate with Shared Drive roles: the RoofCommand service account is the only Manager, humans get Viewer or Content manager. Drive trash retains for 30 days as a second net.
5. **If storage ever leaves Workspace, so do the photos.** Same class of risk as any dependency, mitigated by the fact that everything is exportable and the DB holds every file ID and hash.

### Non-Google fallbacks worth knowing

- **Cloudflare R2:** 10 GB free, then about $0.015/GB/month, so roughly $1/month at RufCo's rate, with no egress fees. A new vendor, but a near-free one. The obvious fallback if Drive quota policy changes.
- **Backblaze B2:** same category, 10 GB free.
- **Thumbnails as database blobs instead of a disk cache:** kills the inode question completely. Rejected in favor of the bounded cache because some GoDaddy shared plans cap individual database size, which would trade one wall for another. Revisit if the plan's DB cap turns out to be generous.
- **Office NAS as the photo archive with Drive offsite:** only worth it if photo volume ever grows an order of magnitude beyond the current estimate.

### Revised hosting verdict

With Drive holding the bytes, all three hosting options work, and the decision becomes about uptime and language rather than storage.

| | **A. Existing GoDaddy shared hosting** | **B. GoDaddy VPS** | **C. Office server** |
|---|---|---|---|
| Now viable? | **Yes** | Yes | Yes |
| Language | PHP 8.3 / Laravel + MySQL (Node is not usable on shared) | Node as specced | Node as specced |
| New recurring | **$0** | ~$20/mo | $0 |
| One-time | $0 | $0 | ~$600 to $900 |
| Photo capacity | Drive-limited, ~10 TB pooled | same | same |
| Host disk/inode growth | Flat | Flat | Flat |
| Background jobs | Cron-driven queue worker, chunked for `max_execution_time` | Full daemon | Full daemon |
| Goes down when | GoDaddy has an incident | GoDaddy has an incident | Office loses power or internet |
| Debuggability | Poor, no root | Full | Full |

**Recommendation, revised again 2026-08-20 after live discovery: Option A.** The account turned out to be real cPanel with PHP 8.4, SSH, Git version control, minute-level cron, Node support via Phusion Passenger, 223,000 free inodes, ~98 GB free disk, and ~98 GB of MySQL headroom. Every objection in the original analysis except one is gone.

Build it in **Laravel 11 / PHP 8.4 / MySQL**, photos in a Google Shared Drive. The choice of PHP over Node here is driven by the **512 MB physical memory ceiling**: a Node server holds the application in RAM continuously, while PHP-FPM releases per request, so the same box carries more concurrent users. Node is technically available but is the wrong fit for this hardware.

The one remaining genuine drawback: **no root access.** Server-level problems mean a GoDaddy ticket. Everything else is now in RoofCommand's favor, including a plan already paid through February 2027, which is also the natural review point for whether 512 MB held up under real use.

Prerequisite before any code goes on this box: **remove or lock down the unmaintained WordPress 6.8.1 install at `rufcollc.com/site`.** It shares the account, nobody maintains it, and it is not the public site.

**The honest framing for Ivan:** Google Drive removes the storage wall, so the question is no longer "will this run out of room" but "what do you want to happen when something breaks, and are you willing to pay about $20 a month to have more options when it does."

### Three-year total cost of ownership, all five options

Monthly price is the wrong comparison, because the option with no monthly price is the one that costs the most build weeks. At $600/week for 20 guaranteed hours, weeks are money. Schedule deltas are estimates and are the least certain figures here.

**REVISED 2026-08-20 after live account discovery. See `GODADDY-DISCOVERY-FINDINGS.md`.**

| Option | Hosting, 3 yrs | Hardware | Extra weeks | Weeks as cost | **3-year total** |
|---|---:|---:|---:|---:|---:|
| **1. Existing GoDaddy cPanel hosting** | $0 | $0 | 0.5 | $300 | **$300** |
| 2. GoDaddy VPS | $720 | $0 | 0 | $0 | **$720** |
| 3. Third-party VPS (Hetzner) | $900 | $0 | 0 | $0 | **$900** |
| 4. Office server | $0 | $750 | 1 | $600 | **$1,350** |
| 5. Office server + VPS failover | $720 | $750 | 1.5 | $900 | **$2,370** |

**What changed and why.** The original table put Option 1 at two extra weeks and third place. That estimate assumed porting finished work from Node to PHP. **No code exists yet.** What actually changes is the planning documents: `DECISION-Stack-and-Architecture.md`, `AGENTS.md`, and the schema DDL from Postgres to MySQL. That is a few days of spec work, not an engineering port. Half a week is the honest number, and it puts Option 1 first by a wide margin on a plan already paid through February 2027.

Schedule delta reasoning:
- **Option 1:** rewrite the specs for Laravel 11 / PHP 8.4 / MySQL instead of Fastify / Node / Postgres. Laravel fits the constraint set well (queues on the database driver, cron-driven workers at minute granularity, a Drive storage adapter, Git deploy over SSH). Estimated +0.5 weeks, plus an unquantified ongoing tax whenever a problem turns out to be server-level and the fix path is a GoDaddy ticket.
- **Option 4:** procurement, build, tunnel setup, UPS, and failover testing. Estimated +1 week.
- **Option 5:** Option 4 plus building and testing the handoff between primary and failover. Estimated +2 weeks.

### Client-facing version

`RufCo-Hosting-Options.pdf` in this folder is the Hunter Ops branded decision document for Ivan: five options with pricing, a side-by-side table, the three-year math, a "when something goes wrong" comparison, the ruled-out list, and a pick-one checkbox page. Source HTML alongside it. **Drafted, not sent.**

It also carries two things Ivan needs to fill in himself: what he actually pays Roofr and CompanyCam (list prices are shown, his invoice numbers are blank), and a flag that his believed ~$35/mailbox Workspace cost is well above the $14/user/month published price for Business Standard, which is worth checking regardless of this decision.

### Items to verify once GoDaddy credentials arrive

These determine whether Option A is real, and none can be answered without access:

- [ ] Is it Web Hosting (cPanel), or Managed WordPress / Website Builder? The latter two cannot host a custom app at all.
- [ ] Which plan, and therefore how much disk and SSH access
- [ ] PHP version available (Laravel 11 needs 8.2+)
- [ ] Minimum cron interval permitted
- [ ] `max_execution_time` and memory limit
- [ ] MySQL per-database size cap
- [ ] Current inode usage of the existing site

---

## On "no external software built in"

Two dependencies in the current design are worth deciding on deliberately rather than by default:

**Google sign-in.** Recommended to keep. RufCo is on Google Workspace, is staying, and is already paying. Using it as the login means no passwords stored, no reset flow to build, MFA inherited from the Phase 1 hardening, and offboarding that actually works: suspend the Workspace account and CRM access dies the same second. Building local accounts instead means building and maintaining password reset, MFA, lockout, and a second offboarding checklist somebody has to remember. That is more code, more risk, and a worse security posture, in exchange for independence from a vendor Ivan is not leaving. If he still wants it, it is buildable, and the cost is roughly a week of Stage A.

**Gmail for email history.** Keep. RoofCommand reads and threads; Gmail stays the system of record for delivery. Making the CRM its own mail server would mean running SMTP, managing deliverability and reputation, and owning the exact failure that generated a BBB complaint for a JobNimbus user. Not worth it, and not in Phase 4 scope anyway.

Everything else in the stack is self-contained: Postgres, MinIO, Caddy, and the app all run on the box with no outside call.

---

## Repository layout

```
RUFCO-RoofCommand-CRM/
├─ AGENTS.md                 Codex operating rules
├─ CLAUDE.md                 existing collaboration notes
├─ docker-compose.yml
├─ Caddyfile
├─ packages/
│  ├─ shared/                Zod schemas, types, enums, permission matrix
│  ├─ api/                   Fastify server
│  │  ├─ src/routes/
│  │  ├─ src/services/
│  │  ├─ src/db/schema.ts    Drizzle schema
│  │  ├─ src/db/migrations/
│  │  ├─ src/jobs/           pg-boss handlers
│  │  └─ test/
│  └─ web/                   Vite React PWA
│     ├─ src/routes/
│     ├─ src/components/
│     ├─ src/offline/        Dexie queue, service worker registration
│     └─ test/
├─ ops/
│  ├─ backup.sh
│  └─ restore-verify.sh
└─ docs/
   ├─ DATA-MODEL.md
   ├─ PERMISSIONS.md
   └─ RUNBOOK.md
```

Monorepo with npm workspaces. One `docker compose up` for local dev with Postgres and MinIO.

---

## Data model (core tables)

Named and typed here so Codex has one source of truth. Phase 5 claim tables are listed because the Phase 4 schema must not have to be torn up to add them.

```
users              id, google_sub, email, name, role, active, created_at, disabled_at
sessions           id, user_id, created_at, expires_at, revoked_at, user_agent

customers          id, name, primary_phone, secondary_phone, email, billing_address,
                   source, notes, created_by, created_at
properties         id, customer_id, address_line1, city, state, postal, lat, lng,
                   year_built, stories, notes
jobs               id, job_number, customer_id, property_id, job_type, status,
                   status_entered_at, owner_user_id, next_action, next_action_due,
                   next_action_owner_id, contract_total, deposit_received,
                   description, created_at, closed_at
job_attributes     job_id, material_type, material_profile, color, manufacturer,
                   squares, pitch, layers, waste_pct, measurement_source,
                   measurement_confidence
job_status_history job_id, from_status, to_status, changed_by, changed_at, note

work_orders        id, job_id, type, assigned_user_id, scheduled_date, window_start,
                   window_end, access_notes, status, created_at, completed_at
checklist_templates    id, job_type, area, name, version, active
checklist_items_tmpl   template_id, position, label, requires_photo, requires_note,
                       requires_number
checklists         id, work_order_id, template_id, template_version
checklist_items    id, checklist_id, position, label, requires_photo, completed_by,
                   completed_at, note, number_value

photos             id, job_id, work_order_id, checklist_item_id, storage_key,
                   thumb_key, captured_at, captured_lat, captured_lng,
                   location_verified, captured_by, uploaded_at, device_hint,
                   width, height, bytes, sha256, mirrored_at, tags[]
documents          id, job_id, kind, filename, storage_key, uploaded_by, uploaded_at,
                   source, sha256

price_book_items   id, code, name, category, unit, unit_cost, unit_price, version,
                   active
assemblies         id, name, job_type, version, active
assembly_lines     assembly_id, price_book_item_id, qty_formula
estimates          id, job_id, revision, status, price_book_version, subtotal, tax,
                   total, created_by, created_at, accepted_at
estimate_lines     estimate_id, position, price_book_item_id, description, qty, unit,
                   unit_cost, unit_price, line_total
invoices           id, job_id, estimate_id, number, issued_at, due_at, total, status
payments           id, job_id, invoice_id, amount, method, reference, received_at,
                   recorded_by

time_entries       id, user_id, work_order_id, job_id, clock_in_at, clock_in_lat,
                   clock_in_lng, clock_out_at, clock_out_lat, clock_out_lng,
                   closeout_note, location_verified
activity           id, job_id, actor_user_id, type, payload jsonb, occurred_at
                   (append-only, no update or delete)
email_links        id, job_id, gmail_message_id, gmail_thread_id, from_addr,
                   to_addrs[], subject, snippet, sent_at, has_attachments, linked_by
reminder_rules     id, name, trigger_type, trigger_config jsonb, audience, cadence,
                   active, created_by
intake_trees       id, job_type, version, tree jsonb, active
intake_answers     id, job_id, tree_version, answers jsonb

-- Phase 5, schema-reserved
claims             id, job_id, carrier, claim_number, adjuster_name, adjuster_phone,
                   adjuster_email, date_of_loss, filed_at, status, status_entered_at,
                   rcv_total, acv_paid, depreciation_held, depreciation_released_at,
                   deductible
supplements        id, claim_id, estimate_revision, submitted_at, amount_requested,
                   amount_approved, approved_at, reason_code, status
permits            id, job_id, jurisdiction, permit_number, applied_at, issued_at,
                   inspection_at, passed_at, status
```

Rules: `activity` is insert-only, enforced by a database trigger. `photos.captured_at`, `captured_lat`, `captured_lng` are never updated after insert, also enforced by trigger. Every table gets `created_at`; nothing is hard deleted, everything soft deletes with `deleted_at` so an export is always complete.

---

## Security baseline

- Google OAuth with `hd` domain restriction plus a database allowlist.
- Permissions enforced server side in a single middleware backed by `packages/shared/permissions.ts`. The UI hides things; the API is what actually protects them.
- All traffic HTTPS via Caddy, HSTS on.
- Presigned URLs for files, 15-minute expiry, never public buckets.
- Secrets in a `.env` on the host only, never in the repo, never opened or edited during normal work.
- Postgres and MinIO bound to the Docker network, not published to the host interface.
- Nightly encrypted backups to Drive, with a monthly restore verification that is actually run and logged, matching the Phase 0 standard.
- Audit trail: the `activity` table plus `job_status_history` plus immutable photo metadata.

---

## Open questions for Ivan

1. **Hosting: Option B (GoDaddy VPS, ~$20/mo, always reachable) or Option C (office server, ~$700 one time, $0/month, offline when the office internet is)?** This decision also picks the programming language, so it has to close before Stage A writes code.
2. GoDaddy credentials, so the actual current hosting plan can be seen. Already on the Next Steps list, and the hosting decision cannot be finalized without it.
3. Which Google Workspace account owns the Shared Drive that holds the photo mirror and backups?
4. Approve Google sign-in as the only login method (no username/password fallback)? Reasoning in the "no external software" section above.
5. Confirm the two scope-change items in `SPEC-Feature-Design.md` (photo capture beyond pull-in; estimate and invoice generation) before any build starts on them.
